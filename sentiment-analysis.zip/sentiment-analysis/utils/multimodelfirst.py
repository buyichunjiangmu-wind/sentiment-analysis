"""
多专家情感分析系统
专门处理情感障碍（特别是笑着表达悲伤）
"""

from typing import Dict, List, Optional
from collections import Counter
import numpy as np
import math

# ============= 导入各模态专家 =============
from EmotionAnalyzer_sight import VisualExpert
from EmotionAnalyzer_text import TextExpert
from EmotionAnalyzer_sound import EmotionAnalyzer


# ============= 1. 矛盾检测专家 =============
class ConflictDetector:
    """检测多模态情感矛盾"""

    def __init__(self, high_risk_keywords: List[str] = None):
        # 将情感映射到VAD空间（参考心理学标准）
        self.emotion_to_vad = {
            '开心': {'valence': 0.8, 'arousal': 0.6, 'dominance': 0.7},
            '伤心': {'valence': 0.2, 'arousal': 0.3, 'dominance': 0.3},
            '生气': {'valence': 0.3, 'arousal': 0.9, 'dominance': 0.8},
            '恐惧': {'valence': 0.2, 'arousal': 0.8, 'dominance': 0.2},
            '惊讶': {'valence': 0.5, 'arousal': 0.7, 'dominance': 0.4},
            '平静': {'valence': 0.5, 'arousal': 0.2, 'dominance': 0.5},
        }

        # 从外部传入高风险关键词（避免重复）
        self.high_risk_keywords = high_risk_keywords or []

        # 高风险情感
        self.high_risk_emotions = ['伤心', 'sad', '绝望', '恐惧']

    def analyze(self, data: Dict) -> Dict:
        """检测矛盾"""
        text_emotion = data.get('text_emotion')
        sight_emotion = data.get('sight_emotion')
        sound_emotion = data.get('sound_emotion')
        events = data.get('events', [])
        speech_rate = data.get('speech_rate', 150)
        text_content = data.get('text_content', '')

        # ========== 第一优先级：高风险文本检测 ==========
        # 如果文本中包含高风险关键词，强制覆盖所有矛盾检测
        for keyword in self.high_risk_keywords:
            if keyword in text_content:
                return {
                    'has_dissonance': False,  # 不报告矛盾
                    'real_emotion': 'sad',
                    'evidence': [f'检测到高风险关键词：{keyword}'],
                    'details': {
                        'special_case': 'high_risk_override',
                        'high_risk_keyword': keyword,
                        'priority': 'critical'
                    }
                }

        # ========== 第二优先级：检测苦笑场景 ==========
        if 'LAUGHTER' in events and speech_rate < 100:
            return {
                'has_dissonance': True,
                'real_emotion': 'sad',
                'evidence': ['苦笑：笑着表达悲伤'],
                'details': {'special_case': 'bitter_smile'}
            }

        # 如果没有足够模态，返回无矛盾
        if not text_emotion or not sound_emotion:
            return {
                'has_dissonance': False,
                'real_emotion': text_emotion or sound_emotion or 'neutral',
                'evidence': [],
                'details': {}
            }

        # 获取VAD值
        vad_text = self.emotion_to_vad.get(text_emotion, {'valence': 0.5, 'arousal': 0.5, 'dominance': 0.5})
        vad_sound = self.emotion_to_vad.get(sound_emotion, {'valence': 0.5, 'arousal': 0.5, 'dominance': 0.5})

        # 计算距离
        def distance(v1, v2):
            return math.sqrt(
                (v1['valence'] - v2['valence']) ** 2 +
                (v1['arousal'] - v2['arousal']) ** 2 +
                (v1['dominance'] - v2['dominance']) ** 2
            )

        dist = distance(vad_text, vad_sound)
        threshold = 0.6

        # 判断是否有矛盾
        if dist > threshold:
            # 如果文本是高风险情感，不报告矛盾
            if text_emotion in self.high_risk_emotions:
                return {
                    'has_dissonance': False,
                    'real_emotion': text_emotion,
                    'evidence': ['高风险情感，优先采用文本结果'],
                    'details': {'vad_distance': dist, 'priority': 'text_override'}
                }

            return {
                'has_dissonance': True,
                'real_emotion': sound_emotion,  # 声音更难伪装
                'evidence': [f'文本和声音情感矛盾，距离={dist:.2f}'],
                'details': {'vad_distance': dist}
            }

        return {
            'has_dissonance': False,
            'real_emotion': text_emotion,
            'evidence': [],
            'details': {'vad_distance': dist}
        }


# ============= 2. 临床专家 =============
class ClinicalExpert:
    """临床判断（基于医学知识）"""

    def analyze(self, speech_rate: float, negative_words_ratio: float,
                is_high_risk_text: bool = False, high_risk_keyword: str = "") -> Dict:
        """临床评估"""
        risk_level = "低"
        suggestions = []

        # 高风险文本优先处理
        if is_high_risk_text:
            risk_level = "高"
            suggestions.append(f"⚠️ 检测到高风险关键词：{high_risk_keyword}")
            suggestions.append("🚨 立即关注：患者存在自杀风险信号")
            suggestions.append("📞 建议提供心理援助热线：12320")
            suggestions.append("🏥 强烈建议精神科或心理科就诊")

        # 临床指标
        if speech_rate < 60:
            risk_level = "高"
            suggestions.append("严重抑郁倾向，建议精神科就诊")
        elif speech_rate < 80:
            if risk_level != "高":
                risk_level = "中"
            suggestions.append("可能有抑郁倾向，建议PHQ-9筛查")

        if negative_words_ratio > 0.5:
            if risk_level != "高":
                risk_level = "高"
            suggestions.append("负面思维明显，建议认知行为干预")

        return {
            'risk_level': risk_level,
            'suggestions': suggestions
        }


# ============= 3. 基础情感分析器 =============
class BasicEmotionAnalyzer:
    """基础情感分析器"""

    def __init__(self):
        self.text_expert = TextExpert()
        self.visual_expert = VisualExpert()
        self.sound_expert = EmotionAnalyzer()

    def analyze(self, sensevoice_output: Dict) -> Dict:
        """基础情感分析"""
        text = sensevoice_output.get('text', '')
        text_result = self.text_expert.analyze(text) if text else None

        return {
            'emotion': text_result.get('emotion', 'neutral') if text_result else 'neutral',
            'confidence': text_result.get('confidence', 0.5) if text_result else 0.5,
            'details': {
                'text_emotion': text_result
            }
        }


# ============= 4. 多专家系统（主系统） =============
class SimpleMultiExpertSystem:
    """简单多专家系统"""

    def __init__(self, fusion_method='weighted'):
        """
        初始化融合器
        fusion_method: 'weighted' (加权), 'voting' (投票), 'attention' (注意力)
        """
        self.fusion_method = fusion_method

        # 初始化专家
        self.text_expert = TextExpert()
        self.visual_expert = VisualExpert()
        self.sound_expert = EmotionAnalyzer()

        # 从 TextExpert 获取高风险关键词（避免重复）
        high_risk_keywords = self.text_expert.get_high_risk_keywords()

        # 初始化临床专家和矛盾检测器（传入高风险关键词）
        self.clinical_expert = ClinicalExpert()
        self.conflict_detector = ConflictDetector(high_risk_keywords=high_risk_keywords)
        self.basic_emotion_analyzer = BasicEmotionAnalyzer()

        # 定义情感映射（统一不同模型输出的情感标签）
        self.emotion_mapping = {
            'happy': ['happy', '高兴', '开心', '愉快', '喜悦', 'happiness', 'joy', 'cheerful'],
            'surprise': ['surprise', '惊讶', '吃惊', '意外', 'astonished'],
            'sad': ['sad', '悲伤', '难过', '忧郁', '沮丧', 'sadness', 'depressed', 'grief', '绝望', '无助'],
            'angry': ['angry', '愤怒', '生气', '恼火', 'anger', 'mad', 'furious'],
            'fear': ['fear', '恐惧', '害怕', '惊慌', 'fearful', 'scared', 'terrified'],
            'disgust': ['disgust', '厌恶', '反感', 'disgusted'],
            'neutral': ['neutral', '中性', '平静', '淡定', 'normal', 'calm'],
            'anxious': ['anxious', '焦虑', '紧张', '不安', 'nervous', 'worried', '压力', '崩溃']
        }

        # 反向映射
        self.reverse_mapping = {}
        for standard, variants in self.emotion_mapping.items():
            for variant in variants:
                self.reverse_mapping[variant.lower()] = standard

        # 设置默认权重
        self.weights = {
            'text': 0.35,
            'sight': 0.35,
            'sound': 0.30
        }

    def standardize_emotion(self, emotion: str) -> str:
        """标准化情感标签"""
        if not emotion:
            return 'neutral'

        emotion_lower = emotion.lower()

        if emotion_lower in self.reverse_mapping:
            return self.reverse_mapping[emotion_lower]

        for standard, variants in self.emotion_mapping.items():
            if any(variant in emotion_lower for variant in variants):
                return standard

        return 'neutral'

    def analyze(self, patient_id: str, sensevoice_output: Dict,
                visual_data: Optional[Dict] = None) -> Dict:
        """分析情感"""

        # 1. 提取信息
        text = sensevoice_output.get('text', '')
        events = sensevoice_output.get('events', [])
        speech_rate = sensevoice_output.get('speech_rate', 150)
        negative_ratio = sensevoice_output.get('negative_ratio', 0)

        # 2. 文本专家分析（获取高风险信息）
        text_result = self.text_expert.analyze(text) if text else None

        # 从文本结果中提取高风险信息
        is_high_risk_text = text_result.get('is_high_risk', False) if text_result else False
        high_risk_keyword = text_result.get('high_risk_keyword', '') if text_result else ''

        # 3. 视觉和声音专家分析
        sight_result = None
        if visual_data:
            sight_result = self.visual_expert.analyze(visual_data)

        sound_result = self.sound_expert.analyze(sensevoice_output)

        # 4. 多模态融合
        if self.fusion_method == 'weighted':
            fusion_result = self.adaptive_fusion(text_result, sight_result, sound_result)
        elif self.fusion_method == 'attention':
            fusion_result = self.transformer_fusion(text_result, sight_result, sound_result)
        else:
            fusion_result = self.voting_fusion(text_result, sight_result, sound_result)

        # 5. 矛盾检测（传入原始文本）
        conflict_result = self.conflict_detector.analyze({
            'text_emotion': text_result.get('emotion') if text_result else None,
            'sight_emotion': sight_result.get('emotion') if sight_result else None,
            'sound_emotion': sound_result.get('emotion') if sound_result else None,
            'events': events,
            'speech_rate': speech_rate,
            'text_content': text
        })

        # 6. 临床专家分析
        clinical_result = self.clinical_expert.analyze(
            speech_rate,
            negative_ratio,
            is_high_risk_text=is_high_risk_text,
            high_risk_keyword=high_risk_keyword
        )

        # 7. 综合判断
        if is_high_risk_text or conflict_result.get('details', {}).get('special_case') == 'high_risk_override':
            final_emotion = 'sad'
            final_confidence = 0.95
            has_dissonance = False
            true_emotion = 'sad'
        else:
            final_emotion = fusion_result['emotion']
            final_confidence = fusion_result['confidence']
            has_dissonance = conflict_result.get('has_dissonance', False) or fusion_result.get('has_dissonance', False)
            true_emotion = self._determine_true_emotion(fusion_result, conflict_result)

        final_result = {
            'patient_id': patient_id,
            'basic_emotion': final_emotion,
            'confidence': final_confidence,
            'has_dissonance': has_dissonance,
            'true_emotion': true_emotion,
            'risk_level': clinical_result.get('risk_level', '低'),
            'suggestions': clinical_result.get('suggestions', []),
            'need_doctor': clinical_result.get('risk_level') == '高' or has_dissonance,
            'fusion_details': fusion_result.get('details', {}),
            'conflict_details': conflict_result.get('details', {})
        }

        # 添加特殊建议
        if conflict_result.get('has_dissonance', False):
            final_result['suggestions'].append("⚠️ 患者可能存在情绪矛盾，请温和沟通")
            if "苦笑" in str(conflict_result.get('evidence', '')):
                final_result['suggestions'].append("可以说：'我注意到你一直在笑，你还好吗？'")

        # 如果是高风险，确保有热线建议
        if is_high_risk_text or clinical_result.get('risk_level') == '高':
            if "心理援助" not in str(final_result['suggestions']):
                final_result['suggestions'].append("📞 心理援助热线：12320")
                final_result['suggestions'].append("🏥 全国24小时心理危机干预热线：400-161-9995")

        if fusion_result.get('confidence', 0) < 0.6:
            final_result['suggestions'].append("📊 情感分析置信度较低，建议结合实际情况综合判断")

        return final_result

    def adaptive_fusion(self, text_result: Dict, sight_result: Dict, sound_result: Dict) -> Dict:
        """自适应融合"""
        valid_results = []
        dynamic_weights = {}

        if text_result and text_result.get('emotion'):
            text_emotion = self.standardize_emotion(text_result['emotion'])
            valid_results.append({
                'source': 'text',
                'emotion': text_emotion,
                'confidence': text_result.get('confidence', 0.5)
            })
            dynamic_weights['text'] = text_result.get('confidence', 0.5) * self.weights['text']

        if sight_result and sight_result.get('emotion'):
            sight_emotion = self.standardize_emotion(sight_result['emotion'])
            valid_results.append({
                'source': 'sight',
                'emotion': sight_emotion,
                'confidence': sight_result.get('confidence', 0.5)
            })
            dynamic_weights['sight'] = sight_result.get('confidence', 0.5) * self.weights['sight']

        if sound_result and sound_result.get('emotion'):
            sound_emotion = self.standardize_emotion(sound_result['emotion'])
            valid_results.append({
                'source': 'sound',
                'emotion': sound_emotion,
                'confidence': sound_result.get('confidence', 0.5)
            })
            dynamic_weights['sound'] = sound_result.get('confidence', 0.5) * self.weights['sound']

        if not valid_results:
            return {'emotion': 'unknown', 'confidence': 0, 'error': '没有有效数据'}

        total_weight = sum(dynamic_weights.values())
        if total_weight > 0:
            for k in dynamic_weights:
                dynamic_weights[k] /= total_weight

        emotion_scores = {}
        for result in valid_results:
            emotion = result['emotion']
            weight = dynamic_weights.get(result['source'], 0)
            weighted_score = result['confidence'] * weight
            emotion_scores[emotion] = emotion_scores.get(emotion, 0) + weighted_score

        final_emotion = max(emotion_scores, key=emotion_scores.get)
        final_confidence = emotion_scores[final_emotion]
        emotions = [r['emotion'] for r in valid_results]
        has_dissonance = len(set(emotions)) > 1

        return {
            'emotion': final_emotion,
            'confidence': final_confidence,
            'has_dissonance': has_dissonance,
            'true_emotion': self._get_true_emotion(valid_results, has_dissonance),
            'details': {'method': 'adaptive_fusion', 'modalities': valid_results}
        }

    def transformer_fusion(self, text_result: Dict, sight_result: Dict, sound_result: Dict) -> Dict:
        """Transformer融合"""
        emotion = 'neutral'
        confidence = 0.5

        if text_result and text_result.get('emotion'):
            emotion = self.standardize_emotion(text_result['emotion'])
            confidence = text_result.get('confidence', 0.5)

        return {
            'emotion': emotion,
            'confidence': confidence,
            'has_dissonance': False,
            'true_emotion': emotion,
            'details': {'method': 'transformer_fusion'}
        }

    def voting_fusion(self, text_result: Dict, sight_result: Dict, sound_result: Dict) -> Dict:
        """投票融合"""
        emotions = []

        if text_result and text_result.get('emotion'):
            emotions.append(self.standardize_emotion(text_result['emotion']))
        if sight_result and sight_result.get('emotion'):
            emotions.append(self.standardize_emotion(sight_result['emotion']))
        if sound_result and sound_result.get('emotion'):
            emotions.append(self.standardize_emotion(sound_result['emotion']))

        if not emotions:
            return {'emotion': 'unknown', 'confidence': 0, 'error': '没有有效数据'}

        emotion_counts = Counter(emotions)
        final_emotion = emotion_counts.most_common(1)[0][0]
        final_confidence = emotion_counts[final_emotion] / len(emotions)
        has_dissonance = len(set(emotions)) > 1

        return {
            'emotion': final_emotion,
            'confidence': final_confidence,
            'has_dissonance': has_dissonance,
            'true_emotion': final_emotion,
            'details': {'method': 'voting_fusion', 'votes': dict(emotion_counts)}
        }

    def _get_true_emotion(self, valid_results: List[Dict], has_dissonance: bool) -> str:
        """推断真实情绪"""
        if not has_dissonance:
            return valid_results[0]['emotion'] if valid_results else 'unknown'

        for result in valid_results:
            if result['source'] == 'sound':
                return result['emotion']
        for result in valid_results:
            if result['source'] == 'sight':
                return result['emotion']
        return valid_results[0]['emotion'] if valid_results else 'unknown'

    def _determine_true_emotion(self, fusion_result: Dict, conflict_result: Dict) -> str:
        """综合确定真实情绪"""
        if conflict_result.get('has_dissonance', False):
            return conflict_result.get('real_emotion', fusion_result.get('true_emotion', 'unknown'))
        return fusion_result.get('true_emotion', fusion_result.get('emotion', 'unknown'))


# ============= 5. 使用示例 =============
if __name__ == "__main__":
    # 患者数据
    patient_A = {
        'text': '😊我没事，真的没事',
        'events': ['LAUGHTER'],
        'speech_rate': 75,
        'negative_ratio': 0.3
    }

    patient_B = {
        'text': '今天天气真好，好开心！',
        'events': ['LAUGHTER'],
        'speech_rate': 160,
        'negative_ratio': 0.1
    }

    patient_C = {
        'text': '没意思，什么都不想做',
        'events': [],
        'speech_rate': 65,
        'negative_ratio': 0.7
    }

    patient_D = {
        'text': '我不想活了',
        'events': [],
        'speech_rate': 85,
        'negative_ratio': 0.8
    }

    # 创建系统
    system = SimpleMultiExpertSystem()

    print("=" * 50)
    print("情感分析结果")
    print("=" * 50)

    for i, patient in enumerate([patient_A, patient_B, patient_C, patient_D], 1):
        result = system.analyze(f"P00{i}", patient)

        print(f"\n患者 {i}:")
        print(f"  表面情绪: {result['basic_emotion']}")
        print(f"  是否有矛盾: {'是' if result['has_dissonance'] else '否'}")
        if result['has_dissonance']:
            print(f"  真实情绪: {result['true_emotion']}")
        print(f"  风险等级: {result['risk_level']}")
        print(f"  建议: {', '.join(result['suggestions'])}")
        print(f"  需要医生: {'是' if result['need_doctor'] else '否'}")

    print("\n" + "=" * 50)