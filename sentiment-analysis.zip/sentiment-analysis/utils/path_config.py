# path_config.py - 统一相对路径配置
import os
import sys


def get_root_dir():
    """获取项目根目录（当前文件所在目录）"""
    return os.path.dirname(os.path.abspath(__file__))


def get_models_dir():
    """获取模型文件夹路径"""
    return os.path.join(get_root_dir(), "models")


def get_sensevoice_path():
    """获取 SenseVoice 模型路径"""
    return os.path.join(get_models_dir(), "sensevoice", "iic", "SenseVoiceSmall")


def get_qwen_path():
    """获取 Qwen 模型路径"""
    return os.path.join(get_models_dir(), "qwen", "Qwen2.5-7B-Instruct")


def get_fer_cache_path():
    """获取 FER 缓存路径"""
    return os.path.join(get_models_dir(), "fer")


def ensure_dirs():
    """确保必要的目录存在"""
    dirs = [
        get_models_dir(),
        os.path.join(get_root_dir(), "cache"),
        get_fer_cache_path()
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)


def setup_all_paths():
    """设置所有环境变量"""
    ensure_dirs()

    # 设置 ModelScope 缓存路径
    os.environ["MODELSCOPE_CACHE"] = get_models_dir()

    # 设置 Transformers 缓存路径
    os.environ["TRANSFORMERS_CACHE"] = os.path.join(get_root_dir(), "cache", "huggingface")
    os.environ["HF_HOME"] = os.path.join(get_root_dir(), "cache", "huggingface")

    # 设置 FER 缓存路径
    os.environ["FER_CACHE_DIR"] = get_fer_cache_path()

    print(f"📁 项目根目录: {get_root_dir()}")
    print(f"📁 模型目录: {get_models_dir()}")

    return get_root_dir(), get_models_dir()


# 自动执行路径设置
setup_all_paths()

if __name__ == "__main__":
    print("路径配置加载完成")
    print(f"  根目录: {get_root_dir()}")
    print(f"  模型目录: {get_models_dir()}")
    print(f"  SenseVoice路径: {get_sensevoice_path()}")
    print(f"  Qwen路径: {get_qwen_path()}")