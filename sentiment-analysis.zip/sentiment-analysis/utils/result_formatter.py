# result_formatter.py
"""
统一结果格式化模块
为Unity前端提供固定的JSON返回格式
"""

from typing import Dict, List, Optional, Any
from datetime import datetime


class ResultFormatter:
    """统一结果格式化器"""

    # 情感 → 动作映射
    EMOTION_TO_ACTION = {
        'happy': 'nod',
        'joy': 'nod',
        'sad': 'head_down',
        'sorrow': 'head_down',
        'angry': 'shake',
        'anger': 'shake',
        'fear': 'shrink',
        'surprise': 'open_eyes',
        'surprised': 'open_eyes',
        'fun': 'wave',
        'neutral': 'idle',
        'anxious': 'fidget',
        'calm': 'idle'
    }

    # 情感 → 建议动作强度
    EMOTION_TO_INTENSITY = {
        'happy': 0.8,
        'sad': 0.6,
        'angry': 0.7,
        'fear': 0.5,
        'surprise': 0.9,
        'neutral': 0.0,
        'anxious': 0.4
    }

    @classmethod
    def format_chat_response(cls, text: str, emotion: str,
                             confidence: float = 0.7,
                             session_id: str = None,
                             audio_url: str = None,
                             extra: Dict = None) -> Dict:
        """
        格式化对话响应（给Unity用）

        Args:
            text: 数字人回复文本
            emotion: 情感标签 (happy/sad/angry/neutral/surprise)
            confidence: 置信度
            session_id: 会话ID
            audio_url: 音频文件URL
            extra: 额外数据

        Returns:
            统一格式的响应字典
        """
        # 获取动作
        action = cls.EMOTION_TO_ACTION.get(emotion.lower(), 'idle')
        intensity = cls.EMOTION_TO_INTENSITY.get(emotion.lower(), 0.5)

        response = {
            "code": 200,
            "message": "success",
            "timestamp": datetime.now().isoformat(),
            "data": {
                "text": text,
                "emotion": emotion,
                "action": action,
                "intensity": intensity,
                "confidence": round(confidence, 3),
                "audio_url": audio_url or f"/audio/{session_id}.wav" if session_id else None
            }
        }

        if extra:
            response["data"].update(extra)

        return response

    @classmethod
    def format_emotion_analysis(cls, emotion: str, confidence: float,
                                risk_level: str = "低",
                                has_dissonance: bool = False,
                                true_emotion: str = None,
                                suggestions: List[str] = None) -> Dict:
        """
        格式化情感分析响应

        Args:
            emotion: 检测到的情绪
            confidence: 置信度
            risk_level: 风险等级 (低/中/高)
            has_dissonance: 是否存在情绪矛盾
            true_emotion: 真实情绪（如有矛盾）
            suggestions: 建议列表

        Returns:
            统一格式的响应字典
        """
        response = {
            "code": 200,
            "message": "success",
            "timestamp": datetime.now().isoformat(),
            "data": {
                "emotion": emotion,
                "confidence": round(confidence, 3),
                "risk_level": risk_level,
                "has_dissonance": has_dissonance,
                "need_doctor": risk_level == "高"
            }
        }

        if true_emotion:
            response["data"]["true_emotion"] = true_emotion

        if suggestions:
            response["data"]["suggestions"] = suggestions[:5]

        return response

    @classmethod
    def format_session_state(cls, session_id: str, current_emotion: str,
                             risk_level: str, history_length: int,
                             created_at: str, last_active: str = None,
                             emotion_trend: str = None) -> Dict:
        """
        格式化会话状态响应

        Args:
            session_id: 会话ID
            current_emotion: 当前情绪
            risk_level: 风险等级
            history_length: 历史记录条数
            created_at: 创建时间
            last_active: 最后活跃时间
            emotion_trend: 情绪趋势

        Returns:
            统一格式的响应字典
        """
        response = {
            "code": 200,
            "message": "success",
            "data": {
                "session_id": session_id,
                "current_emotion": current_emotion,
                "risk_level": risk_level,
                "history_length": history_length,
                "created_at": created_at,
                "last_active": last_active or created_at,
                "is_active": True
            }
        }

        if emotion_trend:
            response["data"]["emotion_trend"] = emotion_trend

        return response

    @classmethod
    def format_health(cls, status: str, device: str,
                      gpu_enabled: bool, uptime: float = None) -> Dict:
        """
        格式化健康检查响应

        Args:
            status: 状态 (ok/error)
            device: 设备信息
            gpu_enabled: GPU是否启用
            uptime: 运行时间（秒）

        Returns:
            统一格式的响应字典
        """
        return {
            "code": 200,
            "message": "success",
            "data": {
                "status": status,
                "service": "emotion_analysis",
                "device": device,
                "gpu_enabled": gpu_enabled,
                "uptime": uptime,
                "timestamp": datetime.now().isoformat()
            }
        }

    @classmethod
    def format_error(cls, error_code: int, error_message: str,
                     details: str = None) -> Dict:
        """
        格式化错误响应

        Args:
            error_code: 错误码
            error_message: 错误消息
            details: 详细信息

        Returns:
            统一格式的错误响应字典
        """
        response = {
            "code": error_code,
            "message": "error",
            "error": error_message,
            "timestamp": datetime.now().isoformat()
        }

        if details:
            response["details"] = details

        return response

    @classmethod
    def get_action_from_emotion(cls, emotion: str) -> str:
        """根据情感获取动作"""
        return cls.EMOTION_TO_ACTION.get(emotion.lower(), 'idle')

    @classmethod
    def get_intensity_from_emotion(cls, emotion: str) -> float:
        """根据情感获取强度"""
        return cls.EMOTION_TO_INTENSITY.get(emotion.lower(), 0.5)


# 简化版快捷函数（便于调用）
def chat_response(text: str, emotion: str, confidence: float = 0.7) -> Dict:
    """快捷：对话响应"""
    return ResultFormatter.format_chat_response(text, emotion, confidence)


def emotion_response(emotion: str, confidence: float, risk_level: str = "低") -> Dict:
    """快捷：情感分析响应"""
    return ResultFormatter.format_emotion_analysis(emotion, confidence, risk_level)


def session_response(session_id: str, current_emotion: str, history_length: int) -> Dict:
    """快捷：会话状态响应"""
    return ResultFormatter.format_session_state(
        session_id, current_emotion, "低", history_length,
        datetime.now().isoformat()
    )


# 测试代码
if __name__ == "__main__":
    # 测试各格式化方法
    print("=" * 50)
    print("测试 ResultFormatter")
    print("=" * 50)

    # 1. 对话响应
    result = ResultFormatter.format_chat_response(
        text="你好，我是数字人助手",
        emotion="happy",
        confidence=0.92,
        session_id="test_001"
    )
    print("\n1. 对话响应:")
    print(result)

    # 2. 情感分析响应
    result = ResultFormatter.format_emotion_analysis(
        emotion="sad",
        confidence=0.85,
        risk_level="高",
        has_dissonance=True,
        true_emotion="sad",
        suggestions=["建议关注", "心理援助热线: 12320"]
    )
    print("\n2. 情感分析响应:")
    print(result)

    # 3. 会话状态响应
    result = ResultFormatter.format_session_state(
        session_id="test_001",
        current_emotion="sad",
        risk_level="中",
        history_length=10,
        created_at="2024-01-01T00:00:00"
    )
    print("\n3. 会话状态响应:")
    print(result)

    # 4. 错误响应
    result = ResultFormatter.format_error(404, "会话不存在")
    print("\n4. 错误响应:")
    print(result)