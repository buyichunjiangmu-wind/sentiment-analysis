# Chat.py - 情感感知对话系统 - 增强共情版本（Qwen2.5 + 4-bit量化）
"""
情感感知对话系统
集成多专家情感分析系统 + Qwen2.5 共情增强模型（4-bit量化）
"""

from typing import List, Dict, Optional
from datetime import datetime
import sys
import os
import torch
import re

# 获取当前文件所在目录
_current_dir = os.path.dirname(os.path.abspath(__file__))

sys.path.append(_current_dir)

from multimodelfirst import SimpleMultiExpertSystem
from EmotionAnalyzer_text import TextExpert
from EmotionAnalyzer_sound import EmotionAnalyzer
from EmotionAnalyzer_sight import VisualExpert


# ============= 增强共情 LLM 包装器（4-bit量化） =============
class EmpatheticLLM:
    """增强共情能力的大语言模型包装器 - 支持4-bit量化"""
    import os
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    def __init__(self,
                 model_name: str =  "./models_text/model_llm/Qwen2.5-7B-Instruct",
                 cache_dir: str = None,
                 use_4bit: bool = True,
                 use_flash_attention: bool = True):
        """
        初始化共情增强LLM

        Args:
            model_name: 模型名称（推荐 Qwen2.5-7B/14B-Instruct）
            cache_dir: 模型缓存目录
            use_4bit: 是否使用4-bit量化（24GB显存下7B模型量化后约5-6GB）
            use_flash_attention: 是否使用Flash Attention 2
        """
        self.model_name = model_name
        self.use_4bit = use_4bit
        self.model = None
        self.tokenizer = None

        print(f"\n{'=' * 50}")
        print(f"加载共情增强模型: {model_name}")
        print(f"4-bit量化: {'启用' if use_4bit else '禁用'}")
        print(f"{'=' * 50}")

        try:
            from transformers import (
                AutoModelForCausalLM,
                AutoTokenizer,
                BitsAndBytesConfig
            )

            # 配置量化参数
            if use_4bit:
                bnb_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.bfloat16,
                    bnb_4bit_use_double_quant=True,
                    bnb_4bit_quant_type="nf4"
                )
                quantization_config = bnb_config
            else:
                quantization_config = None

            # 模型参数
            model_kwargs = {
                "torch_dtype": torch.bfloat16,
                "device_map": "auto",
                "trust_remote_code": True,
                "cache_dir": cache_dir,
            }

            if quantization_config:
                model_kwargs["quantization_config"] = quantization_config

            if use_flash_attention:
                model_kwargs["attn_implementation"] = "flash_attention_2"

            # 加载模型和分词器
            print("正在加载模型（这可能需要几分钟）...")
            self.model = AutoModelForCausalLM.from_pretrained(
                model_name,
                **model_kwargs
            )

            self.tokenizer = AutoTokenizer.from_pretrained(
                model_name,
                cache_dir=cache_dir,
                trust_remote_code=True,
                padding_side="left"
            )

            # 设置pad_token
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token

            print(f"✅ 模型加载成功！")
            if torch.cuda.is_available():
                print(f"   显存占用: ~{torch.cuda.memory_allocated() / 1024 ** 3:.1f} GB")

        except Exception as e:
            print(f"❌ 模型加载失败: {e}")
            print("将使用备用模式（基于规则的共情回复）")
            self.model = None
            self.tokenizer = None

    def generate_response(self,
                          prompt: str,
                          system_prompt: str = None,
                          max_new_tokens: int = 512,
                          temperature: float = 0.7,
                          top_p: float = 0.9,
                          top_k: int = 50) -> Dict:
        """
        生成共情回复

        Args:
            prompt: 用户输入
            system_prompt: 系统提示词
            max_new_tokens: 最大生成token数
            temperature: 温度参数（越高越随机）
            top_p: nucleus sampling参数
            top_k: top-k sampling参数
        """
        if self.model is None:
            return self._fallback_response(prompt)

        try:
            # 构建消息格式（Qwen2.5聊天模板）
            if system_prompt:
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ]
            else:
                messages = [
                    {"role": "user", "content": prompt}
                ]

            # 应用聊天模板
            text = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )

            # Tokenize
            inputs = self.tokenizer(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=4096
            ).to(self.model.device)

            # 生成
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    temperature=temperature,
                    top_p=top_p,
                    top_k=top_k,
                    do_sample=True,
                    pad_token_id=self.tokenizer.pad_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                    repetition_penalty=1.05
                )

            # 解码
            response = self.tokenizer.decode(
                outputs[0][inputs['input_ids'].shape[1]:],
                skip_special_tokens=True
            )

            # 清理回复
            response = response.strip()

            return {
                "response": response,
                "success": True
            }

        except Exception as e:
            print(f"生成失败: {e}")
            return self._fallback_response(prompt)

    def _fallback_response(self, prompt: str) -> Dict:
        """备用回复（当模型不可用时）"""
        # 基于关键词的共情回复
        responses = [
            "我能感受到你此刻的心情，愿意和我多聊聊吗？",
            "听起来这让你感到困扰，我在这里陪着你。",
            "谢谢你愿意分享这些，这需要很大的勇气。",
            "我能理解这种感受，每个人都会有类似的经历。",
            "你并不孤单，我会一直在这里支持你。"
        ]
        import random
        return {
            "response": random.choice(responses),
            "success": False,
            "fallback": True
        }

    def clear_cache(self):
        """清理GPU缓存"""
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
            print("✅ GPU缓存已清理")


# ============= 专家咨询模块 =============
class ExpertConsultant:
    """专家咨询系统 - 调用各专业专家进行深入分析"""

    def __init__(self, fusion_center: SimpleMultiExpertSystem):
        self.fusion_center = fusion_center
        self.text_expert = TextExpert()

        # 初始化声音专家（可选）
        try:
            self.sound_expert = EmotionAnalyzer()
            self.has_sound = True
        except Exception as e:
            self.has_sound = False
            print(f"⚠️ 声音专家初始化失败: {e}")

        # 初始化视觉专家（可选）
        try:
            self.visual_expert = VisualExpert()
            self.has_vision = True
        except Exception as e:
            self.has_vision = False
            print(f"⚠️ 视觉专家初始化失败: {e}")

    def consult_text_expert(self, text: str) -> Dict:
        """咨询文本专家"""
        return self.text_expert.analyze(text)

    def consult_sound_expert(self, audio_path: str = None, audio_features: Dict = None) -> Dict:
        """咨询声音专家"""
        if not self.has_sound:
            return {'error': '声音专家不可用', 'emotion': 'neutral', 'confidence': 0.5}

        if audio_path:
            return self.sound_expert.analyze_sound(audio_path)
        elif audio_features:
            return self.sound_expert.analyze(audio_features)
        return {'emotion': 'neutral', 'confidence': 0.5, 'raw_output': ''}

    def consult_visual_expert(self, image_path: str = None, video_path: str = None) -> Dict:
        """咨询视觉专家"""
        if not self.has_vision:
            return {'error': '视觉专家不可用', 'emotion': 'neutral', 'confidence': 0.5}

        if image_path:
            return self.visual_expert.analyze(image_path)
        elif video_path:
            return self.visual_expert.analyze(video_path)
        return {'emotion': 'neutral', 'confidence': 0.5}

    def comprehensive_analysis(self, text: str, audio_path: str = None,
                               image_path: str = None,video_path: str = None) -> Dict:
        """综合多专家分析"""
        # 获取文本分析结果
        text_result = self.consult_text_expert(text)

        # 调用多专家系统进行综合分析
        if self.fusion_center:
            try:
                # 构建SenseVoice格式的输入
                sensevoice_output = {
                    'text': text,
                    'events': [],
                    'speech_rate': 150,
                    'negative_ratio': 0.0
                }

                # 分析视觉数据
                visual_data = None
                if image_path:
                    visual_data = {'image_path': image_path}
                elif video_path:
                    visual_data = {'video_path': video_path}

                # 调用融合中心
                fusion_result = self.fusion_center.analyze(
                    patient_id="expert_consult",
                    sensevoice_output=sensevoice_output,
                    visual_data=visual_data
                )

                return {
                    'text_analysis': text_result,
                    'overall_emotion': fusion_result.get('basic_emotion', 'neutral'),
                    'confidence': fusion_result.get('confidence', 0.7),
                    'risk_level': fusion_result.get('risk_level', '低'),
                    'has_dissonance': fusion_result.get('has_dissonance', False),
                    'true_emotion': fusion_result.get('true_emotion', 'neutral'),
                    'recommendations': fusion_result.get('suggestions', []),
                    'need_doctor': fusion_result.get('need_doctor', False)
                }
            except Exception as e:
                print(f"融合分析失败: {e}")

        # 降级方案：仅返回文本分析结果
        return {
            'text_analysis': text_result,
            'overall_emotion': text_result.get('emotion', 'neutral'),
            'confidence': text_result.get('confidence', 0.6),
            'risk_level': text_result.get('risk_level', '低'),
            'has_dissonance': False,
            'true_emotion': text_result.get('emotion', 'neutral'),
            'recommendations': [],
            'need_doctor': text_result.get('risk_level') == '高'
        }


# ============= 情感对话机器人 =============
class EmotionalChatBot:
    """情感对话机器人 - 集成多专家分析和LLM共情回复"""

    def __init__(self,
                 fusion_center: SimpleMultiExpertSystem,
                 model_name: str = "Qwen/Qwen2.5-7B-Instruct",
                 model_cache_dir: str = None,
                 use_4bit: bool = True,
                 use_flash_attention: bool = True,
                 use_llm: bool = True):
        """
        初始化对话机器人

        Args:
            fusion_center: 多专家融合系统实例
            model_name: LLM模型名称
            model_cache_dir: 模型缓存目录
            use_4bit: 是否使用4-bit量化
            use_flash_attention: 是否使用Flash Attention
            use_llm: 是否使用LLM（False时仅使用规则回复）
        """
        self.fusion_center = fusion_center
        self.conversation_history: List[Dict] = []
        self.current_emotion = "neutral"
        self.use_llm = use_llm

        # 初始化共情LLM（如果启用）
        self.llm = None
        if use_llm:
            self.llm = EmpatheticLLM(
                model_name=model_name,
                cache_dir=model_cache_dir,
                use_4bit=use_4bit,
                use_flash_attention=use_flash_attention
            )

        # 初始化专家咨询模块
        self.expert_consultant = ExpertConsultant(fusion_center)

        # 系统提示词（增强共情能力）
        self.system_prompt = """你是一个温暖、富有同理心的心理支持助手。你的任务是：
1. 认真倾听用户的感受，不急于给出建议
2. 识别并回应用户的情绪状态
3. 用温和、支持性的语言回应
4. 如果用户表达出极端负面情绪，优先提供心理援助资源
5. 保持对话自然流畅，不要像机器人一样机械回复

记住：你的目标是让用户感到被理解、被接纳。"""

        print("✅ 情感对话机器人初始化完成")

    def chat(self, user_message: str, session_id: str = None) -> Dict:
        """
        处理用户消息，生成共情回复

        Args:
            user_message: 用户输入的消息
            session_id: 会话ID（可选）

        Returns:
            包含回复内容和情感分析结果的字典
        """
        # 1. 情感分析
        sensevoice_output = {
            'text': user_message,
            'events': [],
            'speech_rate': 150,
            'negative_ratio': 0.0
        }

        emotion_result = self.fusion_center.analyze(
            patient_id=session_id or "default",
            sensevoice_output=sensevoice_output,
            visual_data=None
        )

        emotion = emotion_result.get('basic_emotion', 'neutral')
        confidence = emotion_result.get('confidence', 0.7)
        risk_level = emotion_result.get('risk_level', '低')
        has_dissonance = emotion_result.get('has_dissonance', False)
        suggestions = emotion_result.get('suggestions', [])

        self.current_emotion = emotion

        # 2. 保存对话历史
        self.conversation_history.append({
            "role": "user",
            "content": user_message,
            "emotion": emotion,
            "timestamp": datetime.now().isoformat()
        })

        # 3. 生成回复
        if risk_level == "高":
            # 高风险情况：优先提供援助资源
            response = self._handle_high_risk(emotion_result)
        elif self.llm and self.use_llm:
            # 使用LLM生成回复
            prompt = self._build_prompt(user_message, emotion, risk_level, has_dissonance)
            llm_response = self.llm.generate_response(
                prompt=prompt,
                system_prompt=self.system_prompt,
                max_new_tokens=512,
                temperature=0.7
            )
            response = llm_response.get("response", self._get_fallback_reply(emotion))
        else:
            # 使用规则回复
            response = self._get_fallback_reply(emotion)

        # 4. 保存助手回复
        self.conversation_history.append({
            "role": "assistant",
            "content": response,
            "emotion": "neutral",
            "timestamp": datetime.now().isoformat()
        })

        # 5. 限制历史长度
        if len(self.conversation_history) > 20:
            self.conversation_history = self.conversation_history[-20:]

        return {
            "response": response,
            "emotion": emotion,
            "confidence": confidence,
            "risk_level": risk_level,
            "has_dissonance": has_dissonance,
            "suggestions": suggestions,
            "success": True
        }

    def _build_prompt(self, user_message: str, emotion: str,
                      risk_level: str, has_dissonance: bool) -> str:
        """构建带情感上下文的提示词"""
        emotion_desc = {
            'happy': '用户现在很开心',
            'sad': '用户现在很难过',
            'angry': '用户现在很生气',
            'fear': '用户感到害怕',
            'surprise': '用户感到惊讶',
            'neutral': '用户情绪平稳',
            'anxious': '用户感到焦虑'
        }

        prompt = f"""[情感上下文]
{emotion_desc.get(emotion, '用户情绪状态未知')}
{'⚠️ 用户可能存在情绪矛盾（如笑着说悲伤的事）' if has_dissonance else ''}
{'⚠️ 用户表达出较高风险的情绪信号，请谨慎回应' if risk_level == '高' else ''}

[对话历史]
{self._get_recent_history(5)}

[用户当前消息]
{user_message}

请以温暖、共情的方式回复用户："""

        return prompt

    def _get_recent_history(self, n: int = 5) -> str:
        """获取最近的对话历史"""
        recent = self.conversation_history[-n:] if self.conversation_history else []
        history_str = ""
        for msg in recent:
            role = "用户" if msg["role"] == "user" else "助手"
            history_str += f"{role}: {msg['content']}\n"
        return history_str

    def _handle_high_risk(self, emotion_result: Dict) -> str:
        """处理高风险情况"""
        response = """我听到你正在经历一些非常困难的时刻，我想让你知道：你并不孤单，有人在乎你。

如果你需要立即帮助，以下资源可以为你提供支持：
- 心理援助热线：12320
- 全国24小时心理危机干预热线：400-161-9995
- 北京心理危机研究与干预中心：010-82951332

你愿意和我多聊聊你现在的感受吗？"""

        suggestions = emotion_result.get('suggestions', [])
        if suggestions:
            response = f"{response}\n\n{suggestions[0]}"

        return response

    def _get_fallback_reply(self, emotion: str) -> str:
        """备用回复（LLM不可用时）"""
        replies = {
            'happy': "看到你开心，我也很高兴！能和我分享一下吗？",
            'sad': "我能感受到你现在的情绪，愿意和我多说说吗？我在这里陪着你。",
            'angry': "我理解你现在的感受，深呼吸一下，慢慢说。",
            'fear': "不用害怕，这里是安全的，我会一直陪着你。",
            'surprise': "哇，听起来很有趣！能多告诉我一些吗？",
            'anxious': "放轻松，慢慢来，我们一起面对。",
            'neutral': "我明白了，能再多说一些吗？我在认真听。"
        }
        return replies.get(emotion, "我理解你的感受，继续说吧，我在听。")

    def clear_history(self):
        """清空对话历史"""
        self.conversation_history = []
        print("✅ 对话历史已清空")

    def get_conversation_summary(self) -> Dict:
        """获取对话摘要"""
        if not self.conversation_history:
            return {"message": "暂无对话记录"}

        user_messages = [m for m in self.conversation_history if m["role"] == "user"]

        return {
            "total_messages": len(self.conversation_history),
            "user_messages": len(user_messages),
            "current_emotion": self.current_emotion,
            "last_exchange": self.conversation_history[-2:] if len(self.conversation_history) >= 2 else None
        }

    def run_interactive(self):
        """启动交互式对话模式"""
        print("\n" + "=" * 60)
        print("情感对话机器人 - 共情增强版")
        print("=" * 60)
        print("命令:")
        print("  /clear     - 清空对话历史")
        print("  /summary   - 查看对话摘要")
        print("  /exit      - 退出程序")
        print("=" * 60)

        while True:
            try:
                user_input = input("\n你: ").strip()

                if not user_input:
                    continue

                if user_input.lower() in ['/exit', 'exit', 'quit']:
                    print("再见！愿你的每一天都充满阳光 ")
                    break
                elif user_input == '/clear':
                    self.clear_history()
                    continue
                elif user_input == '/summary':
                    summary = self.get_conversation_summary()
                    print(f"\n 对话摘要: {summary}")
                    continue

                # 正常对话
                result = self.chat(user_input)

                print(f"\n 助手 [{result['emotion']}]: {result['response']}")

                if result.get('risk_level') == '高':
                    print("\n⚠️ 温馨提示：如果你感到非常难过，请记得寻求专业帮助。")

            except KeyboardInterrupt:
                print("\n再见！")
                break
            except Exception as e:
                print(f"❌ 错误: {e}")


# ============= 模块测试入口 =============
if __name__ == "__main__":
    # 测试情感对话机器人
    print("测试情感对话机器人模块")
    print("=" * 60)

    # 创建融合中心
    from multimodelfirst import SimpleMultiExpertSystem

    fusion_center = SimpleMultiExpertSystem(fusion_method='weighted')

    # 创建对话机器人
    chatbot = EmotionalChatBot(
        fusion_center=fusion_center,
        use_llm=False  # 测试时使用规则回复，避免加载大模型
    )

    # 测试对话
    test_messages = [
        "我今天心情很好",
        "我感觉很难过",
        "我不想活了"
    ]

    for msg in test_messages:
        print(f"\n用户: {msg}")
        result = chatbot.chat(msg)
        print(f"助手: {result['response']}")
        print(f"情感: {result['emotion']}, 风险: {result['risk_level']}")