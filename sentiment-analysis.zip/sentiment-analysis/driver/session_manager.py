# session_manager.py
"""
会话管理模块
管理多用户会话、对话历史、情绪状态
"""

import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any
from collections import deque


class Session:
    """单个会话对象"""

    def __init__(self, session_id: str = None, max_history: int = 50):
        """
        初始化会话

        Args:
            session_id: 会话ID，不传则自动生成
            max_history: 最大历史记录条数
        """
        self.session_id = session_id or str(uuid.uuid4())[:8]
        self.max_history = max_history
        self.created_at = datetime.now()
        self.last_active = self.created_at
        self.history: List[Dict[str, Any]] = []
        self.current_emotion: str = "neutral"
        self.emotion_history: List[Dict[str, Any]] = []
        self.risk_level: str = "低"
        self.custom_data: Dict[str, Any] = {}

    def add_message(self, role: str, content: str, emotion: str = None) -> None:
        """
        添加对话消息

        Args:
            role: 角色 (user/assistant/system)
            content: 消息内容
            emotion: 情感标签（可选）
        """
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "emotion": emotion
        }
        self.history.append(message)
        self.last_active = datetime.now()

        # 限制历史长度
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:]

    def add_emotion_record(self, emotion: str, confidence: float,
                           risk_level: str = None, has_dissonance: bool = False) -> None:
        """添加情感记录"""
        record = {
            "emotion": emotion,
            "confidence": confidence,
            "risk_level": risk_level or self.risk_level,
            "has_dissonance": has_dissonance,
            "timestamp": datetime.now().isoformat()
        }
        self.emotion_history.append(record)
        self.current_emotion = emotion
        if risk_level:
            self.risk_level = risk_level

    def get_recent_history(self, n: int = 5) -> List[Dict]:
        """获取最近n条对话"""
        return self.history[-n:]

    def get_emotion_trend(self) -> Optional[str]:
        """分析情绪趋势"""
        if len(self.emotion_history) < 3:
            return None

        recent_emotions = [h['emotion'] for h in self.emotion_history[-5:]]
        negative_count = sum(1 for e in recent_emotions if e in ['sad', 'angry', 'fear', 'anxious'])

        if negative_count >= 3:
            return "负面情绪持续，建议关注"
        elif negative_count >= 2:
            return "出现负面情绪倾向"
        return None

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat(),
            "last_active": self.last_active.isoformat(),
            "current_emotion": self.current_emotion,
            "risk_level": self.risk_level,
            "history_length": len(self.history),
            "emotion_history_length": len(self.emotion_history),
            "custom_data": self.custom_data
        }


class SessionManager:
    """会话管理器 - 管理所有用户会话"""

    def __init__(self, max_sessions: int = 100):
        """
        初始化会话管理器

        Args:
            max_sessions: 最大并发会话数
        """
        self.sessions: Dict[str, Session] = {}
        self.max_sessions = max_sessions
        self._cleanup_interval = 3600  # 1小时清理一次

    def create_session(self, session_id: str = None) -> Session:
        """
        创建新会话

        Args:
            session_id: 会话ID（可选）

        Returns:
            创建的Session对象
        """
        # 清理过期会话
        self._cleanup_expired()

        # 检查会话数限制
        if len(self.sessions) >= self.max_sessions:
            self._remove_oldest_session()

        session = Session(session_id)
        self.sessions[session.session_id] = session
        print(f"✅ 创建会话: {session.session_id}")
        return session

    def get_session(self, session_id: str) -> Optional[Session]:
        """
        获取会话

        Args:
            session_id: 会话ID

        Returns:
            Session对象，不存在则返回None
        """
        session = self.sessions.get(session_id)
        if session:
            session.last_active = datetime.now()
        return session

    def get_or_create_session(self, session_id: str = None) -> Session:
        """
        获取或创建会话

        Args:
            session_id: 会话ID

        Returns:
            Session对象
        """
        if session_id and session_id in self.sessions:
            return self.sessions[session_id]
        return self.create_session(session_id)

    def delete_session(self, session_id: str) -> bool:
        """删除会话"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            print(f"删除会话: {session_id}")
            return True
        return False

    def add_message(self, session_id: str, role: str, content: str, emotion: str = None) -> bool:
        """向会话添加消息"""
        session = self.get_session(session_id)
        if not session:
            return False
        session.add_message(role, content, emotion)
        return True

    def update_emotion(self, session_id: str, emotion: str, confidence: float,
                       risk_level: str = None, has_dissonance: bool = False) -> bool:
        """更新会话的情感状态"""
        session = self.get_session(session_id)
        if not session:
            return False
        session.add_emotion_record(emotion, confidence, risk_level, has_dissonance)
        return True

    def get_state(self, session_id: str) -> Optional[Dict]:
        """获取会话状态摘要"""
        session = self.get_session(session_id)
        if not session:
            return None

        return {
            "session_id": session.session_id,
            "current_emotion": session.current_emotion,
            "risk_level": session.risk_level,
            "history_length": len(session.history),
            "emotion_history": session.emotion_history[-10:],  # 最近10条
            "recent_messages": session.get_recent_history(5),
            "emotion_trend": session.get_emotion_trend(),
            "created_at": session.created_at.isoformat(),
            "last_active": session.last_active.isoformat()
        }

    def get_all_sessions(self) -> List[Dict]:
        """获取所有会话摘要"""
        return [s.to_dict() for s in self.sessions.values()]

    def _cleanup_expired(self, max_idle_minutes: int = 30) -> None:
        """清理空闲过久的会话"""
        now = datetime.now()
        expired = []

        for session_id, session in self.sessions.items():
            idle_minutes = (now - session.last_active).total_seconds() / 60
            if idle_minutes > max_idle_minutes:
                expired.append(session_id)

        for session_id in expired:
            self.delete_session(session_id)

    def _remove_oldest_session(self) -> None:
        """移除最旧的会话"""
        if not self.sessions:
            return
        oldest = min(self.sessions.values(), key=lambda s: s.last_active)
        self.delete_session(oldest.session_id)

    def clear_all(self) -> None:
        """清空所有会话"""
        self.sessions.clear()
        print("已清空所有会话")


# 全局单例
_global_session_manager = None


def get_session_manager() -> SessionManager:
    """获取全局会话管理器（单例）"""
    global _global_session_manager
    if _global_session_manager is None:
        _global_session_manager = SessionManager()
    return _global_session_manager


# 测试代码
if __name__ == "__main__":
    # 测试会话管理
    sm = SessionManager()

    # 创建会话
    session = sm.create_session("test_001")
    print(f"会话创建: {session.session_id}")

    # 添加消息
    sm.add_message("test_001", "user", "我今天很难过", "sad")
    sm.add_message("test_001", "assistant", "别难过，我陪着你", "neutral")

    # 更新情感
    sm.update_emotion("test_001", "sad", 0.85, "高", False)

    # 获取状态
    state = sm.get_state("test_001")
    print(f"会话状态: {state}")

    # 获取所有会话
    all_sessions = sm.get_all_sessions()
    print(f"所有会话: {all_sessions}")