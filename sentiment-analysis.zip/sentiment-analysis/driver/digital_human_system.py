# digital_human_system.py - 完整情感数字人系统 v4.0
# 集成：多专家情感分析 + Qwen2.5对话 + TTS + 数字人表情动作控制
# 只做表情
#python digital_human_system.py --mode emotion_only

# 只做动作
#python digital_human_system.py --mode action_only

# 表情+动作+语音
#python digital_human_system.py --mode emotion_action

import os
import sys
import socket
import threading
import time
import uuid
from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ==================== 配置 ====================
@dataclass
class Config:
    """数字人系统配置"""
    udp_ip: str = "127.0.0.1"
    udp_port: int = 5005

    idle_timeout: int = 10
    idle_check_interval: int = 2
    idle_action_interval: int = 5

    default_intensity: float = 0.7
    transition_duration: float = 0.5

    tts_temp_audio: str = "./temp_speech.wav"
    tts_enabled: bool = True

    auto_connect: bool = True
    udp_timeout: float = 0.5

    response_mode: str = "emotion_action"


config = Config()


# ==================== 情感映射 ====================
class EmotionMapper:
    """情感标签 -> 数字人表情参数映射"""

    EMOTION_MAP = {
        'happy': ('joy', 0.8), 'joy': ('joy', 0.8),
        'excited': ('joy', 0.9), 'pleased': ('joy', 0.6),
        'sad': ('sorrow', 0.7), 'sorrow': ('sorrow', 0.7),
        'angry': ('neutral', 0.3), 'anger': ('neutral', 0.3),
        'fear': ('sorrow', 0.6), 'scared': ('sorrow', 0.7),
        'anxious': ('sorrow', 0.6),
        'neutral': ('neutral', 0.0), 'calm': ('neutral', 0.0),
        'surprise': ('fun', 0.8), 'surprised': ('fun', 0.8),
        'fun': ('fun', 0.7),
    }

    @classmethod
    def map(cls, emotion: str) -> Tuple[str, float]:
        emotion_lower = emotion.lower().strip()
        if emotion_lower in cls.EMOTION_MAP:
            return cls.EMOTION_MAP[emotion_lower]
        for key in cls.EMOTION_MAP:
            if key in emotion_lower or emotion_lower in key:
                return cls.EMOTION_MAP[key]
        return ('neutral', 0.0)

    @classmethod
    def get_transition_command(cls, emotion: str, intensity: float = None,
                               duration: float = None) -> str:
        emotion_name, default_intensity = cls.map(emotion)
        intensity = intensity if intensity is not None else default_intensity
        duration = duration if duration is not None else config.transition_duration
        intensity = max(0.0, min(1.0, intensity))
        return f"param_ts:{emotion_name},{intensity:.2f},{duration}"


# ==================== 动作映射 ====================
class ActionMapper:
    """动作名称映射"""

    SUPPORTED_ACTIONS = [
        'Angry', 'Clapping', 'StandingGreeting', 'Thankful',
        'HipHopDancing', 'Singing', 'Cheering', 'Taunt'
    ]

    EMOTION_TO_ACTION = {
        'happy': 'Cheering',
        'joy': 'Cheering',
        'excited': 'Cheering',
        'sad': 'StandingGreeting',
        'sorrow': 'StandingGreeting',
        'angry': 'StandingGreeting',
        'fear': 'StandingGreeting',
        'surprise': 'Taunt',
        'neutral': None,
    }

    @classmethod
    def get_action_for_emotion(cls, emotion: str) -> Optional[str]:
        emotion_lower = emotion.lower().strip()
        return cls.EMOTION_TO_ACTION.get(emotion_lower)

    @classmethod
    def get_action_command(cls, action: str) -> Optional[str]:
        if action is None:
            return None
        if action in cls.SUPPORTED_ACTIONS:
            return f"action:{action}"
        for supported in cls.SUPPORTED_ACTIONS:
            if supported.lower() == action.lower():
                return f"action:{supported}"
        return None


# ==================== UDP 控制器 ====================
class UDPController:
    def __init__(self, ip: str = None, port: int = None):
        self.ip = ip or config.udp_ip
        self.port = port or config.udp_port
        self.sock = None
        self._lock = threading.Lock()
        self._connected = False

    def connect(self) -> bool:
        try:
            if self.sock:
                self.sock.close()
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.settimeout(config.udp_timeout)
            self._connected = True
            print(f"UDP已连接: {self.ip}:{self.port}")
            return True
        except Exception as e:
            print(f"UDP连接失败: {e}")
            self._connected = False
            return False

    def send(self, command: str) -> bool:
        if not self._connected and not self.connect():
            return False
        try:
            with self._lock:
                self.sock.sendto(command.encode('utf-8'), (self.ip, self.port))
                print(f"发送: {command}")
                return True
        except Exception as e:
            print(f"发送失败: {command} - {e}")
            return False

    def set_emotion(self, emotion: str, intensity: float = None,
                    use_transition: bool = True) -> bool:
        if use_transition:
            command = EmotionMapper.get_transition_command(emotion, intensity)
        else:
            command = f"emotion:{emotion},{intensity:.2f}" if intensity else f"emotion:{emotion}"
        return self.send(command)

    def trigger_action(self, action: str) -> bool:
        command = ActionMapper.get_action_command(action)
        if command:
            return self.send(command)
        return False

    def play_audio(self, audio_path: str) -> bool:
        if not os.path.exists(audio_path):
            print(f"音频不存在: {audio_path}")
            return False
        abs_path = os.path.abspath(audio_path)
        command = f"play_audio:{abs_path}"
        return self.send(command)

    def close(self):
        if self.sock:
            try:
                self.sock.close()
            except:
                pass
            self._connected = False
            self.sock = None


# ==================== TTS 文字转语音 ====================
class TTSWrapper:
    def __init__(self):
        self.engine = None
        self._init_engine()

    def _init_engine(self):
        if not config.tts_enabled:
            print("TTS已禁用")
            return
        try:
            import pyttsx3
            self.engine = pyttsx3.init()
            for voice in self.engine.getProperty('voices'):
                voice_name = voice.name.lower() if voice.name else ""
                voice_id = voice.id.lower() if voice.id else ""
                if 'chinese' in voice_name or 'zh' in voice_id:
                    self.engine.setProperty('voice', voice.id)
                    break
            self.engine.setProperty('rate', 180)
            self.engine.setProperty('volume', 0.9)
            print("TTS已就绪")
        except ImportError:
            print("pyttsx3未安装，请运行: pip install pyttsx3")
            self.engine = None
        except Exception as e:
            print(f"TTS初始化失败: {e}")
            self.engine = None

    def text_to_audio(self, text: str, output_path: str = None) -> Optional[str]:
        if self.engine is None:
            return None
        if output_path is None:
            os.makedirs(os.path.dirname(config.tts_temp_audio) or '.', exist_ok=True)
            output_path = config.tts_temp_audio
        try:
            self.engine.save_to_file(text, output_path)
            self.engine.runAndWait()
            return output_path if os.path.exists(output_path) else None
        except Exception as e:
            print(f"TTS失败: {e}")
            return None

    @property
    def available(self) -> bool:
        return self.engine is not None


# ==================== 情感分析服务集成 ====================
class EmotionAnalysisIntegration:
    def __init__(self):
        self.service = None
        self._init_service()

    def _init_service(self):
        try:
            from emotion_service import get_emotion_service
            self.service = get_emotion_service(fusion_method='weighted')
            print("多专家情感分析服务已加载")
        except ImportError as e:
            print(f"情感分析模块未找到: {e}")
            self.service = None
        except Exception as e:
            print(f"情感分析模块加载失败: {e}")
            self.service = None

    def analyze(self, text: str) -> Dict[str, Any]:
        if self.service:
            try:
                result = self.service.analyze_from_text_only(text, patient_id=None)
                data = result.get('data', {})
                return {
                    'emotion': data.get('basic_emotion', 'neutral'),
                    'confidence': data.get('confidence', 0.7),
                    'risk_level': data.get('risk_level', '低'),
                    'has_dissonance': data.get('has_dissonance', False),
                    'true_emotion': data.get('true_emotion', 'neutral'),
                    'suggestions': data.get('suggestions', [])
                }
            except Exception as e:
                print(f"情感分析错误: {e}")

        return self._simple_analyze(text)

    def _simple_analyze(self, text: str) -> Dict[str, Any]:
        text_lower = text.lower()
        positive = ['开心', '高兴', '快乐', '幸福', '美好', '棒', '好', '喜欢']
        negative = ['难过', '伤心', '痛苦', '绝望', '生气', '愤怒', '害怕', '焦虑', '烦', '讨厌']

        pos_count = sum(1 for w in positive if w in text_lower)
        neg_count = sum(1 for w in negative if w in text_lower)

        if pos_count > neg_count:
            emotion = 'happy'
            confidence = min(0.5 + pos_count * 0.1, 0.9)
        elif neg_count > pos_count:
            emotion = 'sad'
            confidence = min(0.5 + neg_count * 0.1, 0.9)
        else:
            emotion = 'neutral'
            confidence = 0.6

        risk_level = '高' if emotion == 'sad' and confidence > 0.7 else '中' if emotion == 'sad' else '低'

        return {
            'emotion': emotion,
            'confidence': confidence,
            'risk_level': risk_level,
            'has_dissonance': False,
            'true_emotion': emotion,
            'suggestions': []
        }

    @property
    def available(self) -> bool:
        return self.service is not None


# ==================== 对话机器人集成 ====================
class ChatBotIntegration:
    def __init__(self):
        self.chat_bot = None
        self._init_chat_bot()

    def _init_chat_bot(self):
        try:
            from Chat import EmotionalChatBot
            self.chat_bot = EmotionalChatBot(
                fusion_center=None,
                use_llm=True
            )
            print("Qwen2.5对话机器人已加载")
        except ImportError as e:
            print(f"对话机器人模块未找到: {e}")
            self.chat_bot = None
        except Exception as e:
            print(f"对话机器人加载失败: {e}")
            self.chat_bot = None

    def chat(self, user_message: str, session_id: str = None) -> Dict[str, Any]:
        if self.chat_bot:
            try:
                result = self.chat_bot.chat(user_message, session_id)
                return {
                    'reply': result.get('text', ''),
                    'emotion': result.get('emotion', 'neutral'),
                    'confidence': result.get('confidence', 0.7),
                    'action': result.get('action', None)
                }
            except Exception as e:
                print(f"对话生成错误: {e}")

        return self._simple_reply(user_message)

    def _simple_reply(self, user_message: str) -> Dict[str, Any]:
        text_lower = user_message.lower()

        if any(w in text_lower for w in ['开心', '高兴', '快乐']):
            reply = "看到你这么开心，我也很高兴！能和我分享一下吗？"
            emotion = "happy"
        elif any(w in text_lower for w in ['难过', '伤心', '痛苦']):
            reply = "我能感受到你现在的心情。我在这里陪着你，愿意和我说说吗？"
            emotion = "sad"
        elif any(w in text_lower for w in ['生气', '愤怒']):
            reply = "我理解你可能感到生气。深呼吸，我在这里陪着你。"
            emotion = "angry"
        elif any(w in text_lower for w in ['害怕', '恐惧', '紧张']):
            reply = "别担心，我在这里。你可以慢慢说，我会一直陪着你。"
            emotion = "fear"
        else:
            reply = "我明白了。有什么我可以帮你的吗？"
            emotion = "neutral"

        return {
            'reply': reply,
            'emotion': emotion,
            'confidence': 0.7,
            'action': None
        }

    @property
    def available(self) -> bool:
        return self.chat_bot is not None


# ==================== 数字人响应控制器 ====================
class DigitalHumanResponseController:
    def __init__(self, udp_controller: UDPController, tts: TTSWrapper = None):
        self.udp = udp_controller
        self.tts = tts
        self.mode = config.response_mode
        print(f"数字人响应模式: {self.mode}")

    def respond_with_reply(self, reply_text: str, emotion: str,
                           action: str = None, intensity: float = None) -> Dict[str, bool]:
        results = {'emotion': False, 'action': False, 'tts': False}

        if self.mode in ['emotion_only', 'emotion_action']:
            results['emotion'] = self.udp.set_emotion(emotion, intensity, True)
            if results['emotion']:
                print(f"数字人表情: {emotion}")

        if self.mode in ['action_only', 'emotion_action']:
            target_action = action
            if target_action is None and self.mode == 'emotion_action':
                target_action = ActionMapper.get_action_for_emotion(emotion)
            if target_action:
                results['action'] = self.udp.trigger_action(target_action)
                if results['action']:
                    print(f"数字人动作: {target_action}")

        if reply_text and self.tts and self.tts.available:
            audio_path = self.tts.text_to_audio(reply_text)
            if audio_path:
                results['tts'] = self.udp.play_audio(audio_path)
                if results['tts']:
                    print(f"TTS播放: {reply_text[:50]}...")

        return results


# ==================== 主数字人系统 ====================
class DigitalHumanSystem:
    def __init__(self, udp_ip: str = "127.0.0.1", udp_port: int = 5005,
                 enable_tts: bool = True, auto_connect: bool = True,
                 response_mode: str = "emotion_action"):
        print("=" * 60)
        print("情感数字人系统 v4.0")
        print("=" * 60)

        config.udp_ip = udp_ip
        config.udp_port = udp_port
        config.tts_enabled = enable_tts
        config.response_mode = response_mode

        self.udp = UDPController(udp_ip, udp_port)
        self.tts = TTSWrapper() if enable_tts else None
        self.emotion_analyzer = EmotionAnalysisIntegration()
        self.chat_bot = ChatBotIntegration()
        self.response = DigitalHumanResponseController(self.udp, self.tts)

        self.is_running = False
        self.current_emotion = "neutral"
        self.current_session_id = str(uuid.uuid4())

        # 待机相关
        self.last_interaction_time = time.time()
        self.last_idle_action_time = 0
        self._idle_monitor_thread = None
        self._idle_monitoring = False
        self._is_idle = False

        if auto_connect:
            self.udp.connect()

        self._start_idle_monitor()
        self._print_status()

    def _start_idle_monitor(self):
        if self._idle_monitoring:
            return
        self._idle_monitoring = True
        self._idle_monitor_thread = threading.Thread(target=self._idle_monitor_loop, daemon=True)
        self._idle_monitor_thread.start()
        print("待机监控已启动")

    def _idle_monitor_loop(self):
        while self._idle_monitoring:
            time.sleep(config.idle_check_interval)

            current_time = time.time()
            idle_seconds = int(current_time - self.last_interaction_time)

            if idle_seconds >= config.idle_timeout:
                if not self._is_idle:
                    self._is_idle = True
                    print(f"\n空闲 {idle_seconds} 秒，进入待机模式")

                if current_time - self.last_idle_action_time >= config.idle_action_interval:
                    self.last_idle_action_time = current_time
                    self._perform_idle_action(idle_seconds)
            else:
                if self._is_idle:
                    self._is_idle = False
                    print(f"\n退出待机模式")

    def _perform_idle_action(self, idle_seconds: int):
        idle_behaviors = [
            (10, 'blink', None, False, ""),
            (15, 'neutral', 'StandingGreeting', False, ""),
            (20, 'fun', 'Taunt', True, "还在吗？"),
            (25, 'fun', 'Taunt', True, "我有点无聊了..."),
            (35, 'neutral', 'StandingGreeting', True, "再不说话我要休息了哦~"),
        ]

        action_to_take = None
        for threshold, emotion, action, speak, message in idle_behaviors:
            if idle_seconds >= threshold:
                action_to_take = (emotion, action, speak, message)

        if action_to_take:
            emotion, action, speak, message = action_to_take
            print(f"[待机] 空闲{idle_seconds}秒: 表情={emotion}, 动作={action}")

            self.udp.set_emotion(emotion, 0.5)

            if action:
                def trigger_idle_action():
                    time.sleep(0.2)
                    self.udp.trigger_action(action)
                threading.Thread(target=trigger_idle_action, daemon=True).start()

            if speak and self.tts and self.tts.available and message:
                def idle_speak():
                    time.sleep(0.4)
                    audio_path = self.tts.text_to_audio(message)
                    if audio_path:
                        self.udp.play_audio(audio_path)
                threading.Thread(target=idle_speak, daemon=True).start()

    def _print_status(self):
        print("\n系统状态:")
        print(f"   UDP目标: {config.udp_ip}:{config.udp_port}")
        print(f"   TTS: {'可用' if self.tts and self.tts.available else '不可用'}")
        print(f"   情感分析: {'多专家模式' if self.emotion_analyzer.available else '备用模式'}")
        print(f"   对话机器人: {'Qwen2.5' if self.chat_bot.available else '备用模式'}")
        print(f"   响应模式: {config.response_mode}")
        print()

    def process_message(self, user_message: str, session_id: str = None,
                        auto_respond: bool = True) -> Dict[str, Any]:
        self.last_interaction_time = time.time()

        print(f"\n用户: {user_message[:50]}...")

        emotion_result = self.emotion_analyzer.analyze(user_message)
        user_emotion = emotion_result['emotion']
        confidence = emotion_result['confidence']
        risk_level = emotion_result['risk_level']

        print(f"情感分析: {user_emotion} (置信度:{confidence:.2f}, 风险:{risk_level})")

        chat_result = self.chat_bot.chat(user_message, session_id or self.current_session_id)
        reply_text = chat_result['reply']
        suggested_emotion = chat_result.get('emotion', user_emotion)
        suggested_action = chat_result.get('action')

        print(f"数字人回复: {reply_text[:50]}...")

        digital_human_emotion = suggested_emotion if suggested_emotion else user_emotion

        response_results = {}
        if auto_respond:
            response_results = self.response.respond_with_reply(
                reply_text=reply_text,
                emotion=digital_human_emotion,
                action=suggested_action,
                intensity=emotion_result.get('intensity')
            )

        self.current_emotion = digital_human_emotion

        return {
            'success': True,
            'user_message': user_message,
            'user_emotion': user_emotion,
            'user_emotion_confidence': confidence,
            'user_risk_level': risk_level,
            'reply_text': reply_text,
            'digital_human_emotion': digital_human_emotion,
            'digital_human_action': suggested_action,
            'response_results': response_results,
            'session_id': session_id or self.current_session_id
        }

    def start_interactive(self):
        print("\n" + "=" * 60)
        print("交互式模式")
        print("=" * 60)
        print("直接输入文字，数字人会根据你的情绪做出共情回应")
        print("\n命令:")
        print("  /状态    - 查看当前状态")
        print("  /退出    - 退出程序")
        print("=" * 60)
        print(f"当前响应模式: {config.response_mode}")
        print("=" * 60)

        self.is_running = True

        while self.is_running:
            try:
                user_input = input("\n你: ").strip()

                if not user_input:
                    continue

                if user_input in ['/退出', 'exit', 'quit']:
                    print("再见！")
                    self.is_running = False

                elif user_input == '/状态':
                    print(f"\n当前状态:")
                    print(f"   响应模式: {config.response_mode}")
                    print(f"   当前表情: {self.current_emotion}")
                    print(f"   TTS: {'可用' if self.tts and self.tts.available else '不可用'}")
                    print(f"   情感分析: {'多专家模式' if self.emotion_analyzer.available else '备用模式'}")
                    print(f"   对话机器人: {'Qwen2.5' if self.chat_bot.available else '备用模式'}")

                else:
                    result = self.process_message(user_input, auto_respond=True)
                    print(f"\n数字人: {result['reply_text']}")

            except KeyboardInterrupt:
                print("\n再见！")
                break
            except Exception as e:
                print(f"错误: {e}")

    def shutdown(self):
        print("\n关闭系统...")
        self.is_running = False
        self._idle_monitoring = False
        self.udp.close()
        print("系统已关闭")


# ==================== 命令行入口 ====================
def main():
    import argparse

    parser = argparse.ArgumentParser(description='情感数字人系统 v4.0')
    parser.add_argument('--ip', type=str, default='127.0.0.1', help='数字人程序IP')
    parser.add_argument('--port', type=int, default=5005, help='UDP端口')
    parser.add_argument('--no-tts', action='store_true', help='禁用TTS')
    parser.add_argument('--mode', type=str, default='emotion_action',
                        choices=['emotion_only', 'action_only', 'emotion_action'],
                        help='响应模式')

    args = parser.parse_args()

    system = DigitalHumanSystem(
        udp_ip=args.ip,
        udp_port=args.port,
        enable_tts=not args.no_tts,
        response_mode=args.mode
    )

    try:
        system.start_interactive()
    finally:
        system.shutdown()


if __name__ == "__main__":
    main()