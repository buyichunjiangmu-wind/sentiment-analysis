# digital_human_system.py - 完整情感数字人系统 v4.0（三合一固定版+待机）
# 功能：表情 + 动作 + TTS语音 + 待机主动互动
# 只有一个命令，表情+动作+语音同时执行
#python actdigital_human_system.py
import os
import sys
import socket
import threading
import time
import uuid
import random
from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ==================== 配置 ====================
@dataclass
class Config:
    """数字人系统配置"""
    udp_ip: str = "127.0.0.1"
    udp_port: int = 5005
    tts_temp_audio: str = "./temp_speech.wav"
    tts_enabled: bool = True
    auto_connect: bool = True
    udp_timeout: float = 0.5
    transition_duration: float = 0.5

    # 待机配置
    idle_timeout: int = 10  # 空闲超时（秒），之后触发待机动作
    idle_check_interval: int = 2  # 空闲检查间隔（秒）
    idle_action_interval: int = 8  # 待机动作间隔（秒）


config = Config()


# ==================== 情感→表情+动作映射（共情原则） ====================
class EmotionActionMapper:
    """用户情绪 → 数字人（表情+动作）映射"""

    MAPPING = {
        'happy': ('joy', 'Clapping', 0.8),
        'joy': ('joy', 'Clapping', 0.8),
        'excited': ('joy', 'Clapping', 0.9),
        'pleased': ('joy', 'Thankful', 0.6),
        'sad': ('sorrow',None , 0.6),
        'sorrow': ('sorrow', None, 0.7),
        'angry': ('sorrow', None, 0.3),
        'anger': ('sorrow', None, 0.3),
        'fear': ('sorrow', None, 0.5),
        'scared': ('sorrow', None, 0.6),
        'anxious': ('sorrow', None, 0.5),
        'surprise': ('fun', 'Clapping', 0.7),
        'surprised': ('fun', 'Clapping', 0.7),
        'neutral': ('neutral', None, 0.0),
        'calm': ('neutral', None, 0.0),
    }

    @classmethod
    def get(cls, emotion: str) -> Tuple[str, Optional[str], float]:
        emotion_lower = emotion.lower().strip()
        if emotion_lower in cls.MAPPING:
            return cls.MAPPING[emotion_lower]
        for key in cls.MAPPING:
            if key in emotion_lower or emotion_lower in key:
                return cls.MAPPING[key]
        return ('neutral', None, 0.0)


# ==================== UDP控制器 ====================
class UDPController:
    def __init__(self):
        self.sock = None
        self._lock = threading.Lock()
        self._connected = False

    def connect(self) -> bool:
        try:
            if self.sock:
                self.sock.close()
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.settimeout(config.udp_timeout)
            self._connected = True
            print(f"✅ UDP已连接: {config.udp_ip}:{config.udp_port}")
            return True
        except Exception as e:
            print(f"❌ UDP连接失败: {e}")
            return False

    def send(self, command: str) -> bool:
        if not self._connected and not self.connect():
            return False
        try:
            with self._lock:
                self.sock.sendto(command.encode('utf-8'), (config.udp_ip, config.udp_port))
                print(f"📤 {command}")
                return True
        except Exception as e:
            print(f"❌ 发送失败: {e}")
            return False

    def set_emotion(self, emotion: str, intensity: float = 0.7) -> bool:
        return self.send(f"param_ts:{emotion},{intensity:.2f},{config.transition_duration}")

    def trigger_action(self, action: str) -> bool:
        if action:
            return self.send(f"action:{action}")
        return False

    def play_audio(self, audio_path: str) -> bool:
        if os.path.exists(audio_path):
            return self.send(f"play_audio:{os.path.abspath(audio_path)}")
        return False

    def close(self):
        if self.sock:
            self.sock.close()
            self._connected = False


# ==================== TTS语音 ====================
class TTSWrapper:
    def __init__(self):
        self.engine = None
        self._init_engine()

    def _init_engine(self):
        if not config.tts_enabled:
            print("⚠️ TTS已禁用")
            return
        try:
            import pyttsx3
            self.engine = pyttsx3.init()
            for voice in self.engine.getProperty('voices'):
                if 'chinese' in voice.name.lower() or 'zh' in voice.id.lower():
                    self.engine.setProperty('voice', voice.id)
                    break
            self.engine.setProperty('rate', 180)
            self.engine.setProperty('volume', 0.9)
            print("✅ TTS已就绪")
        except ImportError:
            print("⚠️ pyttsx3未安装，请运行: pip install pyttsx3")
            self.engine = None
        except Exception as e:
            print(f"⚠️ TTS初始化失败: {e}")
            self.engine = None

    def speak(self, text: str) -> Optional[str]:
        if self.engine is None:
            return None
        try:
            os.makedirs(os.path.dirname(config.tts_temp_audio) or '.', exist_ok=True)
            self.engine.save_to_file(text, config.tts_temp_audio)
            self.engine.runAndWait()
            return config.tts_temp_audio
        except Exception as e:
            print(f"❌ TTS失败: {e}")
            return None

    @property
    def available(self):
        return self.engine is not None


# ==================== 情感分析服务集成 ====================
class EmotionAnalysisIntegration:
    def __init__(self):
        self.service = None
        self._init_service()

    def _init_service(self):
        try:
            from emotion_service import get_emotion_service
            self.service = get_emotion_service(fusion_method='weighted')
            print("✅ 多专家情感分析服务已加载")
        except ImportError as e:
            print(f"⚠️ 情感分析模块未找到: {e}")
            self.service = None
        except Exception as e:
            print(f"⚠️ 情感分析模块加载失败: {e}")
            self.service = None

    def analyze(self, text: str) -> Dict[str, Any]:
        if self.service:
            try:
                result = self.service.analyze_from_text_only(text, patient_id=None)
                data = result.get('data', {})
                return {
                    'emotion': data.get('basic_emotion', 'neutral'),
                    'confidence': data.get('confidence', 0.7),
                    'risk_level': data.get('risk_level', '低'),
                    'has_dissonance': data.get('has_dissonance', False),
                    'true_emotion': data.get('true_emotion', 'neutral'),
                    'suggestions': data.get('suggestions', [])
                }
            except Exception as e:
                print(f"情感分析错误: {e}")
        return self._simple_analyze(text)

    def _simple_analyze(self, text: str) -> Dict[str, Any]:
        text_lower = text.lower()
        positive = ['开心', '高兴', '快乐', '幸福', '美好', '棒', '好', '喜欢']
        negative = ['难过', '伤心', '痛苦', '绝望', '生气', '愤怒', '害怕', '焦虑', '烦', '讨厌']
        pos_count = sum(1 for w in positive if w in text_lower)
        neg_count = sum(1 for w in negative if w in text_lower)
        if pos_count > neg_count:
            emotion = 'happy'
            confidence = min(0.5 + pos_count * 0.1, 0.9)
        elif neg_count > pos_count:
            emotion = 'sad'
            confidence = min(0.5 + neg_count * 0.1, 0.9)
        else:
            emotion = 'neutral'
            confidence = 0.6
        risk_level = '高' if emotion == 'sad' and confidence > 0.7 else '中' if emotion == 'sad' else '低'
        return {
            'emotion': emotion,
            'confidence': confidence,
            'risk_level': risk_level,
            'has_dissonance': False,
            'true_emotion': emotion,
            'suggestions': []
        }

    @property
    def available(self):
        return self.service is not None


# ==================== 对话机器人集成 ====================
class ChatBotIntegration:
    def __init__(self):
        self.chat_bot = None
        self._init_chat_bot()

    def _init_chat_bot(self):
        try:
            from ChatGPT import EmotionalChatBot
            self.chat_bot = EmotionalChatBot(fusion_center=None, use_llm=True)
            print("✅ Qwen2.5对话机器人已加载")
        except ImportError as e:
            print(f"⚠️ 对话机器人模块未找到: {e}")
            self.chat_bot = None
        except Exception as e:
            print(f"⚠️ 对话机器人加载失败: {e}")
            self.chat_bot = None

    def chat(self, user_message: str, session_id: str = None) -> Dict[str, Any]:
        if self.chat_bot:
            try:
                result = self.chat_bot.chat(user_message, session_id)
                return {
                    'reply': result.get('text', ''),
                    'emotion': result.get('emotion', 'neutral'),
                    'confidence': result.get('confidence', 0.7),
                    'action': result.get('action', None)
                }
            except Exception as e:
                print(f"对话生成错误: {e}")
        return self._simple_reply(user_message)

    def _simple_reply(self, user_message: str) -> Dict[str, Any]:
        text_lower = user_message.lower()
        if any(w in text_lower for w in ['开心', '高兴', '快乐']):
            reply = "看到你这么开心，我也很高兴！能和我分享一下吗？"
            emotion = "happy"
        elif any(w in text_lower for w in ['难过', '伤心', '痛苦']):
            reply = "我能感受到你现在的心情。我在这里陪着你，愿意和我说说吗？"
            emotion = "sad"
        elif any(w in text_lower for w in ['生气', '愤怒']):
            reply = "我理解你可能感到生气。深呼吸，我在这里陪着你。"
            emotion = "angry"
        elif any(w in text_lower for w in ['害怕', '恐惧', '紧张']):
            reply = "别担心，我在这里。你可以慢慢说，我会一直陪着你。"
            emotion = "fear"
        else:
            reply = "我明白了。有什么我可以帮你的吗？"
            emotion = "neutral"
        return {
            'reply': reply,
            'emotion': emotion,
            'confidence': 0.7,
            'action': None
        }

    @property
    def available(self):
        return self.chat_bot is not None


# ==================== 主系统（三合一固定版+待机） ====================
class DigitalHumanSystem:
    """
    完整的情感数字人系统 v4.0（三合一固定版+待机）
    功能：表情 + 动作 + TTS语音 + 待机主动互动
    """

    def __init__(self, udp_ip: str = "127.0.0.1", udp_port: int = 5005, enable_tts: bool = True):
        print("=" * 60)
        print(" 情感数字人系统 v4.0 (三合一完整版+待机)")
        print("=" * 60)
        print("功能: 表情  + 动作  + 语音  + 待机 ")
        print("=" * 60)

        # 配置
        config.udp_ip = udp_ip
        config.udp_port = udp_port
        config.tts_enabled = enable_tts

        # 初始化各模块
        self.udp = UDPController()
        self.tts = TTSWrapper() if enable_tts else None
        self.emotion_analyzer = EmotionAnalysisIntegration()
        self.chat_bot = ChatBotIntegration()

        # 状态
        self.current_emotion = "neutral"
        self.current_session_id = str(uuid.uuid4())

        # 待机相关
        self.last_interaction_time = time.time()
        self.last_idle_action_time = 0
        self._idle_monitor_thread = None
        self._idle_monitoring = False
        self._is_idle = False

        # 自动连接
        self.udp.connect()

        # 启动待机监控
        self._start_idle_monitor()

        # 打印状态
        self._print_status()
        #开机打招呼
        self._greeting_on_start()

    def _greeting_on_start(self):
        """开机时主动打招呼"""
        print("\n" + "=" * 60)
        print(" 数字人已启动，正在向你打招呼...")
        print("=" * 60)

        # 执行打招呼动作
        self.udp.set_emotion("joy", 0.8)  # 开心表情
        time.sleep(0.2)
        self.udp.trigger_action("Standing_Greeting")

        # 播放语音（可选）
        if self.tts and self.tts.available:
            def speak_greeting():
                time.sleep(0.5)
                audio_path = self.tts.speak("你好我叫知南，很高兴见到你！")
                if audio_path:
                    self.udp.play_audio(audio_path)

            threading.Thread(target=speak_greeting, daemon=True).start()

    def _start_idle_monitor(self):
        """启动待机监控线程"""
        if self._idle_monitoring:
            return
        self._idle_monitoring = True
        self._idle_monitor_thread = threading.Thread(target=self._idle_monitor_loop, daemon=True)
        self._idle_monitor_thread.start()
        print("✅ 待机监控已启动")

    def _idle_monitor_loop(self):
        """待机监控循环"""
        while self._idle_monitoring:
            time.sleep(config.idle_check_interval)

            current_time = time.time()
            idle_seconds = int(current_time - self.last_interaction_time)

            # 检查是否进入待机状态
            if idle_seconds >= config.idle_timeout:
                if not self._is_idle:
                    self._is_idle = True
                    print(f"\n 空闲 {idle_seconds} 秒，进入待机模式")

                # 定期执行待机动作（避免过于频繁）
                if current_time - self.last_idle_action_time >= config.idle_action_interval:
                    self.last_idle_action_time = current_time
                    self._perform_idle_action(idle_seconds)
            else:
                if self._is_idle:
                    self._is_idle = False
                    print(f"\n 退出待机模式")

    def _perform_idle_action(self, idle_seconds: int):
        """执行待机动作（根据空闲时长选择不同行为）"""

        # 定义待机行为：空闲秒数 -> (表情, 动作, 是否说话, 消息)
        idle_behaviors = [
            (10, 'blink', None, False, ""),
            (15, 'neutral', 'Standing_Greeting', False, ""),
            (20, 'fun', 'Singing', True),
            (25, 'fun', 'Taunt', True, "还在吗？"),
            (35, 'angry', 'Angry', True),
            (40, 'neutral', 'Standing_Greeting', True, "再不说话我要休息了哦~"),  # 35秒：提醒
        ]

        # 找到适合当前空闲时长的行为
        action_to_take = None
        for threshold, emotion, action, speak, message in idle_behaviors:
            if idle_seconds >= threshold:
                action_to_take = (emotion, action, speak, message)

        if action_to_take:
            emotion, action, speak, message = action_to_take

            print(f" [待机] 空闲{idle_seconds}秒: 表情={emotion}, 动作={action}")

            # 执行表情
            self.udp.set_emotion(emotion, 0.5)

            # 执行动作
            if action:
                def trigger_idle_action():
                    time.sleep(0.2)
                    self.udp.trigger_action(action)

                    # 如果是打招呼，把头复位
                    if action == 'Standing_Greeting':
                        time.sleep(0.15)
                        self.udp.send("bone:Head,0,0,0,0.2")
                        print(" [待机] 修正仰头动作")
                threading.Thread(target=trigger_idle_action, daemon=True).start()

            # 说话（如果需要）
            if speak and self.tts and self.tts.available and message:
                def idle_speak():
                    time.sleep(0.4)
                    audio_path = self.tts.speak(message)
                    if audio_path:
                        self.udp.play_audio(audio_path)

                threading.Thread(target=idle_speak, daemon=True).start()

    def _print_status(self):
        """打印系统状态"""
        print("\n 系统状态:")
        print(f"   UDP目标: {config.udp_ip}:{config.udp_port}")
        print(f"   TTS: {'✅ 可用' if self.tts and self.tts.available else ' 不可用'}")
        print(f"   情感分析: {'✅ 多专家模式' if self.emotion_analyzer.available else ' 备用模式'}")
        print(f"   对话机器人: {'✅ Qwen2.5' if self.chat_bot.available else ' 备用模式'}")
        print(f"   待机监控: ✅ 运行中 (空闲{config.idle_timeout}秒触发)")
        print()

    def respond(self, user_message: str) -> Dict[str, Any]:
        """
        核心方法：三合一响应用户输入
        自动执行：表情 + 动作 + 语音
        """
        # 更新最后交互时间（退出待机）
        self.last_interaction_time = time.time()

        print(f"\n{'=' * 50}")
        print(f"👤 用户: {user_message}")

        # 步骤1：情感分析
        analysis = self.emotion_analyzer.analyze(user_message)
        user_emotion = analysis['emotion']
        confidence = analysis['confidence']
        risk_level = analysis['risk_level']
        print(f" 情感分析: {user_emotion} (置信度:{confidence:.2f}, 风险:{risk_level})")

        # 步骤2：生成回复（通过对话机器人）
        chat_result = self.chat_bot.chat(user_message, self.current_session_id)
        reply_text = chat_result['reply']
        suggested_emotion = chat_result.get('emotion', user_emotion)
        suggested_action = chat_result.get('action')
        print(f" 数字人回复: {reply_text}")

        # 步骤3：确定数字人表情和动作（共情原则）
        digital_emotion, digital_action, intensity = EmotionActionMapper.get(suggested_emotion)
        print(f" 数字人策略: 表情={digital_emotion}, 动作={digital_action}")

        # 步骤4：执行表情（使用渐变，更自然）
        print(f"😀 执行表情: {digital_emotion}")
        self.udp.set_emotion(digital_emotion, intensity)

        # 步骤5：执行动作（稍微延迟，让表情先到位）
        if digital_action:
            def trigger_action():
                time.sleep(0.3)
                print(f" 执行动作: {digital_action}")
                self.udp.trigger_action(digital_action)

                # 如果是打招呼，把头复位
                if digital_action == 'Standing_Greeting':
                    # 1. 先锁定头部，防止仰头
                    self.udp.send("bone:Head,0,0,0,0.0")  # 立即锁定
                    time.sleep(0.15)

                    self.udp.trigger_action(digital_action)

                    def keep_head_straight():
                        for i in range(5):
                            time.sleep(0.1)
                            self.udp.send("bone:Head,0,0,0,0.05")

                    threading.Thread(target=keep_head_straight, daemon=True).start()
                    print(" 修正仰头动作")
            threading.Thread(target=trigger_action, daemon=True).start()

        # 步骤6：TTS语音（稍微延迟，让表情和动作先展示）
        if self.tts and self.tts.available:
            def play_tts():
                time.sleep(0.5)
                print(f" 播放语音...")
                audio_path = self.tts.speak(reply_text)
                if audio_path:
                    self.udp.play_audio(audio_path)

            threading.Thread(target=play_tts, daemon=True).start()
        else:
            print(f"🔊 (语音不可用)")

        # 更新状态
        self.current_emotion = digital_emotion

        return {
            'success': True,
            'user_emotion': user_emotion,
            'user_confidence': confidence,
            'risk_level': risk_level,
            'digital_emotion': digital_emotion,
            'digital_action': digital_action,
            'reply': reply_text
        }

    def start(self):
        """启动交互模式"""
        print("\n" + "=" * 60)
        print("💬 交互式对话模式")
        print("=" * 60)
        print("直接输入文字，数字人会同时做出表情、动作和语音回应")
        print(f"空闲 {config.idle_timeout} 秒后，数字人会主动互动")
        print("\n命令:")
        print("  /状态    - 查看当前状态")
        print("  /退出    - 退出程序")
        print("=" * 60)
        print("示例输入: '我今天很开心' / '我很难过' / '气死我了'")
        print("=" * 60)

        while True:
            try:
                user_input = input("\n👤 你: ").strip()

                if not user_input:
                    continue

                if user_input in ['/退出', 'exit', 'quit']:
                    print("👋 再见！")
                    break

                elif user_input == '/状态':
                    print(f"\n 当前状态:")
                    print(f"   数字人表情: {self.current_emotion}")
                    print(f"   UDP目标: {config.udp_ip}:{config.udp_port}")
                    print(f"   TTS: {' 可用' if self.tts and self.tts.available else ' 不可用'}")
                    print(f"   情感分析: {' 多专家模式' if self.emotion_analyzer.available else '⚠️ 备用模式'}")
                    print(f"   对话机器人: {' Qwen2.5' if self.chat_bot.available else ' 备用模式'}")

                else:
                    # 正常对话
                    result = self.respond(user_input)
                    print(f"\n 数字人: {result['reply']}")

            except KeyboardInterrupt:
                print("\n 再见！")
                break
            except Exception as e:
                print(f" 错误: {e}")

    def shutdown(self):
        """关闭系统"""
        print("\n 关闭系统...")
        self._idle_monitoring = False
        self.udp.close()
        print(" 系统已关闭")


# ==================== 入口 ====================
def main():
    import argparse

    parser = argparse.ArgumentParser(description='情感数字人系统 v4.0（三合一固定版+待机）')
    parser.add_argument('--ip', type=str, default='127.0.0.1', help='数字人程序IP')
    parser.add_argument('--port', type=int, default=5005, help='UDP端口')
    parser.add_argument('--no-tts', action='store_true', help='禁用TTS')

    args = parser.parse_args()

    system = DigitalHumanSystem(
        udp_ip=args.ip,
        udp_port=args.port,
        enable_tts=not args.no_tts
    )

    try:
        system.start()
    finally:
        system.shutdown()


if __name__ == "__main__":
    main()