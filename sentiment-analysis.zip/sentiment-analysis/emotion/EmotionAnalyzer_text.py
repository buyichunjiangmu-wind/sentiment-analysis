# EmotionAnalyzer_text.py - 增强版，集成高风险词汇库

class TextExpert:
    """文本情感分析专家 - 增强规则版"""

    def __init__(self):
        # 高风险关键词（最高优先级）
        self.high_risk_keywords = {
            'sad': [
                '不想活', '想死', '自杀', '结束生命', '活不下去', '死了算了',
                '不想活了', '活着没意思', '没意思活下去', '绝望', '无望',
                '没有希望', '看不到希望', '走投无路', '撑不下去', '受不了了'
            ]
        }

        # 严重负面情绪
        self.severe_negative = {
            'sad': [
                '痛苦', '崩溃', '绝望', '无助', '抑郁', '重度抑郁',
                '无法承受', '坚持不住', '太难受', '痛不欲生'
            ]
        }

        # 常规情感关键词（带权重）
        self.emotion_keywords = {
            'happy': {
                'keywords': ['开心', '高兴', '快乐', '喜悦', '幸福', '美好', '愉快', '棒', '真好', '哈哈'],
                'weight': 0.8
            },
            'sad': {
                'keywords': ['难过', '伤心', '悲伤', '沮丧', '郁闷', '失落', '心酸', '痛苦', '难受'],
                'weight': 0.8
            },
            'angry': {
                'keywords': ['生气', '愤怒', '恼火', '气愤', '不满', '恨', '讨厌'],
                'weight': 0.7
            },
            'fear': {
                'keywords': ['害怕', '恐惧', '紧张', '担心', '惊慌', '恐慌', '不安'],
                'weight': 0.7
            },
            'anxious': {
                'keywords': ['焦虑', '烦躁', '心神不宁', '坐立不安', '压力大'],
                'weight': 0.75
            },
            'neutral': {
                'keywords': ['还行', '一般', '还好', '普通', '没什么'],
                'weight': 0.5
            }
        }

        # 上下文增强规则
        self.context_rules = [
            {'pattern': ['不', '没'], 'emotion': 'neutral', 'boost': 0.3},
        ]

    def analyze(self, text):
        """
        分析文本情感

        Returns:
            dict: {
                'emotion': str,
                'confidence': float,
                'risk_level': str,
                'is_high_risk': bool,
                'high_risk_keyword': str,  # 新增：返回触发的高风险关键词
                'details': dict
            }
        """
        if not text or not isinstance(text, str):
            return {
                'emotion': 'neutral',
                'confidence': 0.5,
                'risk_level': '低',
                'is_high_risk': False,
                'high_risk_keyword': '',
                'details': {}
            }

        text_lower = text.lower()

        # ========== 第一优先级：高风险关键词检测 ==========
        for keyword in self.high_risk_keywords['sad']:
            if keyword in text_lower:
                return {
                    'emotion': 'sad',
                    'confidence': 0.95,
                    'risk_level': '高',
                    'is_high_risk': True,
                    'high_risk_keyword': keyword,  # 返回具体的关键词
                    'details': {
                        'detected_keyword': keyword,
                        'alert': 'CRITICAL',
                        'reason': '检测到自杀风险信号'
                    }
                }

        # ========== 第二优先级：严重负面情绪 ==========
        for keyword in self.severe_negative['sad']:
            if keyword in text_lower:
                return {
                    'emotion': 'sad',
                    'confidence': 0.85,
                    'risk_level': '高',
                    'is_high_risk': True,
                    'high_risk_keyword': keyword,
                    'details': {
                        'detected_keyword': keyword,
                        'alert': 'HIGH_RISK',
                        'reason': '严重负面情绪表达'
                    }
                }

        # ========== 第三优先级：常规情感检测 ==========
        emotion_scores = {}

        for emotion, data in self.emotion_keywords.items():
            score = 0
            for keyword in data['keywords']:
                if keyword in text_lower:
                    score += 1

            if score > 0:
                base_conf = min(score / len(data['keywords']) + 0.2, data['weight'])
                emotion_scores[emotion] = base_conf

        # ========== 上下文增强 ==========
        has_negation = any(neg in text_lower for neg in ['不', '没', '无'])

        if has_negation and emotion_scores:
            for emotion in ['sad', 'angry', 'fear']:
                if emotion in emotion_scores:
                    emotion_scores[emotion] *= 0.6

        # ========== 确定最终情感 ==========
        if emotion_scores:
            main_emotion = max(emotion_scores, key=emotion_scores.get)
            confidence = emotion_scores[main_emotion]

            if main_emotion in ['sad', 'anxious']:
                risk_level = '中' if confidence > 0.7 else '低'
            else:
                risk_level = '低'

            if main_emotion == 'sad' and confidence > 0.8:
                risk_level = '高'

            return {
                'emotion': main_emotion,
                'confidence': min(confidence, 0.95),
                'risk_level': risk_level,
                'is_high_risk': risk_level == '高',
                'high_risk_keyword': '',
                'details': {
                    'scores': emotion_scores,
                    'matched_keywords': True
                }
            }

        # ========== 默认中性 ==========
        return {
            'emotion': 'neutral',
            'confidence': 0.6,
            'risk_level': '低',
            'is_high_risk': False,
            'high_risk_keyword': '',
            'details': {
                'reason': '未检测到明确情感'
            }
        }

    def get_high_risk_keywords(self):
        """获取高风险关键词列表（供其他模块使用）"""
        return self.high_risk_keywords['sad'] + self.severe_negative['sad']

    def analyze_batch(self, texts):
        """批量分析"""
        results = []
        for text in texts:
            results.append(self.analyze(text))
        return results


# ========== 测试代码 ==========
if __name__ == "__main__":
    expert = TextExpert()

    test_cases = [
        "我今天特别开心",
        "我好难过，心情不好",
        "我不想活了",
        "我感觉很绝望，看不到希望",
        "我没事，真的没事",
        "好生气啊",
        "我压力好大，快崩溃了",
        "随便吧，无所谓",
        "我想死，活着没意思",
        "今天天气真好"
    ]

    print("=" * 60)
    print("文本情感分析测试")
    print("=" * 60)

    for text in test_cases:
        result = expert.analyze(text)
        risk_emoji = '🔴' if result['risk_level'] == '高' else '🟡' if result['risk_level'] == '中' else '🟢'

        print(f"\n文本: {text}")
        print(f"  情感: {result['emotion']} (置信度: {result['confidence']:.2f})")
        print(f"  风险: {risk_emoji} {result['risk_level']}")

        if result.get('is_high_risk'):
            print(f"  ⚠️ 高风险检测: {result['details'].get('reason', '')}")

        if result.get('high_risk_keyword'):
            print(f"  触发关键词: {result['high_risk_keyword']}")