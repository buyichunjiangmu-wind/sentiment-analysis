# EmotionAnalyzer_sight.py
from fer.fer import FER
import cv2
import os


class VisualExpert:
    """
    视觉情感分析专家（基于表情）
    """

    def __init__(self):
        print("正在加载视觉专家模型 (FER)...")
        self.detector = FER(mtcnn=False)
        print("视觉专家加载完成！")

    def analyze_sight(self, video_path):
        """分析视频中的人脸表情"""
        if video_path.endswith(('.mp4', '.avi', '.mov', '.mkv')):
            cap = cv2.VideoCapture(video_path)
            ret, frame = cap.read()
            cap.release()
            if not ret:
                return {
                    'emotion': 'unknown',
                    'confidence': 0.0,
                    'all_emotions': {},
                    'face_detected': False
                }
        else:
            frame = cv2.imread(video_path)
            if frame is None:
                return {
                    'emotion': 'unknown',
                    'confidence': 0.0,
                    'all_emotions': {},
                    'face_detected': False
                }

        result = self.detector.detect_emotions(frame)

        if not result:
            return {
                'emotion': 'no_face',
                'confidence': 0.0,
                'all_emotions': {},
                'face_detected': False
            }

        face = result[0]
        emotions = face['emotions']
        dominant_emotion = max(emotions, key=emotions.get)
        dominant_confidence = emotions[dominant_emotion]

        emotion_mapping = {
            'angry': 'angry',
            'disgust': 'disgust',
            'fear': 'fear',
            'happy': 'happy',
            'sad': 'sad',
            'surprise': 'surprise',
            'neutral': 'neutral'
        }

        return {
            'emotion': emotion_mapping.get(dominant_emotion, 'neutral'),
            'confidence': round(dominant_confidence, 3),
            'all_emotions': emotions,
            'face_detected': True
        }

    def analyze(self, visual_data):
        """
        多专家系统调用的统一接口

        参数 visual_data 可以是：
        1. 视频/图像路径字符串
        2. 字典，包含 'video_path' 或 'image_path' 字段
        """
        # 如果是字符串，直接作为路径
        if isinstance(visual_data, str):
            return self.analyze_sight(visual_data)

        # 如果是字典，提取路径
        if isinstance(visual_data, dict):
            if 'video_path' in visual_data:
                return self.analyze_sight(visual_data['video_path'])
            elif 'image_path' in visual_data:
                return self.analyze_sight(visual_data['image_path'])
            elif 'image' in visual_data:
                # 如果直接传图像帧，可以在这里处理
                return self._analyze_frame(visual_data['image'])

        return None

    def _analyze_frame(self, frame):
        """分析图像帧"""
        result = self.detector.detect_emotions(frame)
        if not result:
            return {
                'emotion': 'unknown',
                'confidence': 0.0,
                'all_emotions': {},
                'face_detected': False
            }

        face = result[0]
        emotions = face['emotions']
        dominant_emotion = max(emotions, key=emotions.get)

        emotion_mapping = {
            'angry': 'angry',
            'disgust': 'disgust',
            'fear': 'fear',
            'happy': 'happy',
            'sad': 'sad',
            'surprise': 'surprise',
            'neutral': 'neutral'
        }

        return {
            'emotion': emotion_mapping.get(dominant_emotion, 'neutral'),
            'confidence': round(emotions[dominant_emotion], 3),
            'all_emotions': emotions,
            'face_detected': True
        }


# 测试代码
if __name__ == "__main__":
    expert = VisualExpert()
    # 测试时需要提供真实的图片路径
    # result = expert.analyze("D:/PythonProject/test_face.jpg")
    # print(result)