# emotion_service.py
"""
情感分析服务 - 统一对外接口
支持接收外部数据（文本、音频路径、图像路径）进行多模态分析
"""
import os
import base64
import tempfile
from typing import Dict, Optional, Union
from pathlib import Path

from EmotionAnalyzer_sight import VisualExpert
from EmotionAnalyzer_text import TextExpert
from EmotionAnalyzer_sound import EmotionAnalyzer
from multimodelfirst import SimpleMultiExpertSystem


class EmotionAnalysisService:
    """
    情感分析服务类
    提供统一的API接口，供后端调用
    """

    def __init__(self, fusion_method: str = 'weighted'):
        """
        初始化服务

        Args:
            fusion_method: 融合方法 ('weighted', 'voting', 'attention')
        """
        print("正在初始化情感分析服务...")

        # 初始化各专家
        self.text_expert = TextExpert()
        self.visual_expert = VisualExpert()
        self.sound_expert = EmotionAnalyzer()

        # 初始化多专家系统
        self.multi_expert = SimpleMultiExpertSystem(fusion_method=fusion_method)

        # 临时文件目录（用于保存上传的音频/图像）
        self.temp_dir = Path(tempfile.gettempdir()) / "emotion_analysis_temp"
        self.temp_dir.mkdir(exist_ok=True)

        print("情感分析服务初始化完成！")

    def analyze_from_text_only(self, text: str, patient_id: str = "unknown") -> Dict:
        """
        仅基于文本进行情感分析

        Args:
            text: 文本内容
            patient_id: 患者ID

        Returns:
            分析结果字典
        """
        # 模拟SenseVoice输出格式
        sensevoice_output = {
            'text': text,
            'events': [],
            'speech_rate': 150,  # 默认语速
            'negative_ratio': 0.0
        }

        # 调用多专家系统
        result = self.multi_expert.analyze(patient_id, sensevoice_output, visual_data=None)

        return result

    def analyze_from_audio(
            self,
            audio_path: str,
            patient_id: str = "unknown",
            text_override: Optional[str] = None
    ) -> Dict:
        """
        基于音频进行情感分析

        Args:
            audio_path: 音频文件路径（支持本地路径）
            patient_id: 患者ID
            text_override: 可选的文本覆盖（如果ASR识别不准，可手动传入文本）

        Returns:
            分析结果字典
        """
        # 1. 使用声音专家分析
        sound_result = self.sound_expert.analyze_sound(audio_path)

        # 2. 获取识别文本（或使用覆盖文本）
        if text_override:
            text = text_override
        else:
            text = sound_result.get('display_text', '')

        # 3. 提取事件和情感
        raw_output = sound_result.get('raw_output', '')

        # 解析事件（笑声、哭声等）
        events = []
        if '<|LAUGHTER|>' in raw_output:
            events.append('LAUGHTER')
        if '<|CRYING|>' in raw_output:
            events.append('CRYING')

        # 构建SenseVoice输出格式
        sensevoice_output = {
            'text': text,
            'events': events,
            'speech_rate': self._estimate_speech_rate(audio_path),  # 估算语速
            'negative_ratio': self._calculate_negative_ratio(text),
            'sound_emotion': sound_result.get('emotion', '平静'),
            'sound_confidence': sound_result.get('confidence', 0.5),
            'raw_audio_output': raw_output
        }

        # 4. 调用多专家系统
        result = self.multi_expert.analyze(patient_id, sensevoice_output, visual_data=None)

        # 添加声音专家的原始结果
        result['audio_details'] = sound_result

        return result

    def analyze_from_audio_base64(
            self,
            audio_base64: str,
            patient_id: str = "unknown",
            text_override: Optional[str] = None
    ) -> Dict:
        """
        基于Base64编码的音频进行分析（适用于API接收）

        Args:
            audio_base64: Base64编码的音频数据
            patient_id: 患者ID
            text_override: 可选的文本覆盖

        Returns:
            分析结果字典
        """
        # 保存临时文件
        import uuid
        temp_filename = self.temp_dir / f"audio_{uuid.uuid4().hex}.wav"

        try:
            # 解码并保存
            audio_data = base64.b64decode(audio_base64)
            with open(temp_filename, 'wb') as f:
                f.write(audio_data)

            # 分析
            result = self.analyze_from_audio(str(temp_filename), patient_id, text_override)

            return result

        finally:
            # 清理临时文件
            if temp_filename.exists():
                temp_filename.unlink()

    def analyze_full_multimodal(
            self,
            text: Optional[str] = None,
            audio_path: Optional[str] = None,
            image_path: Optional[str] = None,
            patient_id: str = "unknown"
    ) -> Dict:
        """
        完整的多模态分析（文本+音频+图像）

        Args:
            text: 文本内容
            audio_path: 音频文件路径
            image_path: 图像/视频文件路径
            patient_id: 患者ID

        Returns:
            分析结果字典
        """
        # 1. 处理音频
        if audio_path:
            sound_result = self.sound_expert.analyze_sound(audio_path)
            raw_output = sound_result.get('raw_output', '')
            events = []
            if '<|LAUGHTER|>' in raw_output:
                events.append('LAUGHTER')
            if '<|CRYING|>' in raw_output:
                events.append('CRYING')

            sensevoice_output = {
                'text': text or sound_result.get('display_text', ''),
                'events': events,
                'speech_rate': self._estimate_speech_rate(audio_path),
                'negative_ratio': self._calculate_negative_ratio(text or ''),
                'sound_emotion': sound_result.get('emotion', '平静'),
                'sound_confidence': sound_result.get('confidence', 0.5)
            }
        else:
            # 无音频时使用纯文本
            sensevoice_output = {
                'text': text or '',
                'events': [],
                'speech_rate': 150,
                'negative_ratio': self._calculate_negative_ratio(text or '')
            }

        # 2. 处理视觉数据
        visual_data = None
        if image_path:
            visual_data = {'image_path': image_path}
        elif audio_path:
            # 也可以尝试从音频同目录找同名的视频文件
            pass

        # 3. 调用多专家系统
        result = self.multi_expert.analyze(patient_id, sensevoice_output, visual_data)

        # 添加额外信息
        if audio_path:
            result['audio_details'] = sound_result

        return result

    def _estimate_speech_rate(self, audio_path: str) -> float:
        """估算语速（字/分钟）"""
        # 简化实现，实际可以用librosa计算
        # 这里返回默认值，后续可以优化
        try:
            import librosa
            duration = librosa.get_duration(filename=audio_path)
            # 假设平均每字0.3秒，约200字/分钟
            # 实际应从ASR结果获取字数
            return 150  # 默认值
        except:
            return 150

    def _calculate_negative_ratio(self, text: str) -> float:
        """计算负面词汇比例"""
        if not text:
            return 0.0

        negative_words = ['难过', '伤心', '痛苦', '绝望', '不想', '不好', '难受', '郁闷', '崩溃']
        total_words = len(text)
        if total_words == 0:
            return 0.0

        negative_count = sum(1 for word in negative_words if word in text)
        return min(negative_count / (total_words / 2), 1.0)  # 简单估算

    def get_analysis_summary(self, result: Dict) -> Dict:
        """
        提取分析结果的关键信息，便于前端展示

        Args:
            result: analyze方法返回的完整结果

        Returns:
            简化的结果摘要
        """
        return {
            'patient_id': result.get('patient_id'),
            'basic_emotion': result.get('basic_emotion'),
            'confidence': result.get('confidence'),
            'true_emotion': result.get('true_emotion'),
            'has_dissonance': result.get('has_dissonance'),
            'risk_level': result.get('risk_level'),
            'need_doctor': result.get('need_doctor'),
            'suggestions': result.get('suggestions', [])[:3],  # 只返回前3条建议
            'is_high_risk': result.get('risk_level') == '高'
        }


# 全局单例服务（避免重复加载模型）
_global_service = None


def get_emotion_service(fusion_method: str = 'weighted') -> EmotionAnalysisService:
    """获取全局单例服务"""
    global _global_service
    if _global_service is None:
        _global_service = EmotionAnalysisService(fusion_method)
    return _global_service