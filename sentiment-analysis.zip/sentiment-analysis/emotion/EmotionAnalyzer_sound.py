"""
THCHS-30 语音识别性能测试脚本 + SenseVoice情感分析
支持 CER 和 WER 计算，自动进行文本归一化，自动处理路径引用
"""

# ==================== 解决 OpenMP 冲突 ====================
import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# ==================== 设置模型下载路径 ====================

# 改为（使用打包后的相对路径）
import os
import sys

current_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(current_dir,  "models_text", "emotion_model_sound")
os.environ["MODELSCOPE_CACHE"] = model_path


MODEL_NAME = os.path.join(model_path, "iic", "SenseVoiceSmall")  # 或直接指定本地路径

# ==================== 修改 DATA_DIR 为相对路径 ====================
# 原路径: D:\情感分析数据\data_thchs30\train
# 改为项目目录下的相对路径
DATA_DIR = os.path.join(current_dir, "data", "data_thchs30", "train")

# 基础目录（用于验证路径）
BASE_DATA_DIR = os.path.join(current_dir, "data", "data_thchs30")

# 确保数据目录存在，如果不存在则创建
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(BASE_DATA_DIR, exist_ok=True)

# ==================== 导入依赖 ====================
import re
import csv
from typing import List, Tuple, Dict

import torch
from funasr import AutoModel
from funasr.utils.postprocess_utils import rich_transcription_postprocess
from jiwer import wer, cer
from tqdm import tqdm

# ==================== 配置参数 ====================
# 数据集路径（音频和标注文件都在这个目录下）- 已改为上面的相对路径
# DATA_DIR = r"D:\情感分析数据\data_thchs30\train"  # 已注释

# 测试样本数量（-1 表示全部测试）
NUM_TEST_SAMPLES = 100

# 输出文件 - 改为相对路径
OUTPUT_CSV = os.path.join(current_dir, "output", "asr_test_results.csv")
OUTPUT_SUMMARY = os.path.join(current_dir, "output", "asr_test_summary.txt")

# 确保输出目录存在
os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)

# 模型配置
# MODEL_NAME = "iic/SenseVoiceSmall"  # 已改为上面的本地路径
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# ==================== 情感分析器类 ====================

class EmotionAnalyzer:
    """SenseVoice情感分析器"""

    def __init__(self, model_path: str = None):
        print("正在加载模型，首次加载可能需要2-3分钟...")
        if model_path is None:
            model_path = MODEL_NAME
        self.model = self.model_load(model_path)

    def analyze(self, sensevoice_output):
        return {
            'emotion': sensevoice_output.get('sound_emotion', '平静'),
            'confidence': sensevoice_output.get('sound_confidence', 0.5)
        }

    def model_load(self, model_path: str = None):
        if model_path:
            self.model = AutoModel(
                model=model_path,
                trust_remote_code=True,
                vad_model="fsmn-vad",
                vad_kwargs={"max_single_segment_time": 30000},
                device=DEVICE
            )
        else:
            self.model = AutoModel(
                model=MODEL_NAME,
                device=DEVICE,
                disable_update=True,
                trust_remote_code=True
            )
        print("模型加载完成！")
        return self.model

    def custom_postprocess(self, text: str) -> str:
        """自定义后处理，将标签转换为中文"""
        text = text.replace("<|HAPPY|>", "[开心]")
        text = text.replace("<|SAD|>", "[伤心]")
        text = text.replace("<|ANGRY|>", "[生气]")
        text = text.replace("<|FEARFUL|>", "[恐惧]")
        text = text.replace("<|DISGUSTED|>", "[厌恶]")
        text = text.replace("<|SURPRISED|>", "[惊讶]")
        text = text.replace("<|NEUTRAL|>", "[中性]")
        text = text.replace("<|MUSIC|>", "[音乐]")
        text = text.replace("<|LAUGHTER|>", "[笑声]")
        text = text.replace("<|APPLAUSE|>", "[掌声]")
        text = text.replace("<|CRYING|>", "[哭声]")
        text = text.replace("<|Cough/Sneeze|>", "[咳嗽]")
        text = text.replace("<|Alarm|>", "[警报声]")

        # 移除未匹配的标签
        text = re.sub(r'<\|[^>]+\|>', '', text)
        return text.strip()

    def analyze_sound(self, audio_path: str) -> Dict:
        """分析音频文件，返回情感结果"""
        res = self.model.generate(
            input=audio_path,
            language="auto",
            use_itn=True,
            batch_size_s=60,
            merge_vad=True
        )
        raw_text = res[0]["text"]
        emotion = self.extract_emotion(raw_text)
        confidence = self.get_confidence(raw_text)
        return {
            'emotion': emotion,
            'confidence': confidence,
            'raw_output': raw_text,
            'display_text': self.custom_postprocess(raw_text)
        }

    def extract_emotion(self, raw_text: str) -> str:
        """从SenseVoiceSmall输出中提取情感标签"""
        if '<|HAPPY|>' in raw_text:
            return '开心'
        elif '<|SAD|>' in raw_text:
            return '伤心'
        elif '<|ANGRY|>' in raw_text:
            return '生气'
        elif '<|FEARFUL|>' in raw_text:
            return '恐惧'
        elif '<|DISGUSTED|>' in raw_text:
            return '厌恶'
        elif '<|SURPRISED|>' in raw_text:
            return '惊讶'
        else:
            return '平静'

    def get_confidence(self, raw_text: str) -> float:
        """根据情感标签强度返回置信度"""
        if '<|HAPPY|>' in raw_text or '<|SAD|>' in raw_text:
            return 0.85
        else:
            return 0.6

    def transcribe(self, audio_path: str) -> str:
        """语音识别（返回原始文本）"""
        if not os.path.exists(audio_path):
            return "[ERROR] 音频文件不存在"

        try:
            res = self.model.generate(
                input=audio_path,
                batch_size=1,
                language="zh",
                use_itn=True,
                disable_progress=True
            )
            if res and len(res) > 0:
                text = res[0].get("text", "")
                return text.strip()
            return ""
        except Exception as e:
            print(f"识别出错: {e}")
            return f"[ERROR] {str(e)}"


# ==================== 文本归一化函数 ====================

def extract_chinese_only(text: str) -> str:
    """只提取中文字符，移除拼音、数字、标点、空格等"""
    # 匹配中文字符（Unicode范围：\u4e00-\u9fff）
    chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)
    return ''.join(chinese_chars)


def normalize_text(text: str, remove_punct: bool = True) -> str:
    """
    文本归一化：移除情感标签、统一数字格式、可选移除标点

    专门用于 THCHS-30 数据集，处理包含拼音的标注文本
    """
    # 1. 移除特殊标签 <|xxx|>
    text = re.sub(r'<\|[^>]+\|>', '', text)

    # 2. 移除情感标签 [中性]、[开心]、[悲伤] 等
    text = re.sub(r'\[.*?\]', '', text)

    # 3. 提取中文字符（核心：移除拼音）
    text = extract_chinese_only(text)

    return text


def char_split(text: str) -> str:
    """将中文字符串按字符切分，用空格分隔"""
    return ' '.join(list(text))


# ==================== 标注文件加载（支持路径引用） ====================

def extract_chinese_from_trn(content: str) -> str:
    """
    从 THCHS-30 的 .trn 文件中提取纯中文文本

    THCHS-30 的 .trn 文件格式示例：
    绿 是 阳春 烟 景 大块 文章 的 底色 四月 的 林 峦 更是 绿 得 鲜活 秀媚 诗意 盎然
    lv4 shi4 yang2 chun1 yan1 jing3 da4 kuai4 wen2 zha...

    只取第一行（中文部分），并移除空格
    """
    # 按行分割
    lines = content.split('\n')
    if not lines:
        return ""

    # 第一行通常是中文文本
    chinese_line = lines[0].strip()

    # 移除空格
    chinese_line = chinese_line.replace(' ', '')

    # 确保只包含中文字符
    chinese_line = extract_chinese_only(chinese_line)

    return chinese_line


def get_real_text(trn_file_path: str, base_dir: str, depth: int = 0, verbose: bool = False) -> str:
    """
    递归获取真实的标注文本（只提取中文部分，忽略拼音）

    Args:
        trn_file_path: .trn 文件路径
        base_dir: 基础目录
        depth: 递归深度（防止无限循环）
        verbose: 是否打印详细信息（仅测试时使用）

    Returns:
        纯中文文本内容
    """
    if depth > 5:  # 防止无限递归
        return ""

    if not os.path.exists(trn_file_path):
        return ""

    try:
        with open(trn_file_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()

        # 如果是路径引用（以 ../ 或 .\ 开头）
        if content.startswith('../') or content.startswith('.\\') or content.startswith('/'):
            # 构建绝对路径
            real_path = os.path.normpath(os.path.join(base_dir, content))
            # 递归读取真实文件
            return get_real_text(real_path, os.path.dirname(real_path), depth + 1, verbose)

        # 否则，从内容中提取中文部分
        return extract_chinese_from_trn(content)

    except Exception as e:
        if verbose:
            print(f"读取文件失败 {trn_file_path}: {e}")
        return ""


def load_thchs30_transcripts(data_dir: str, num_samples: int = -1, verbose: bool = False) -> List[Tuple[str, str]]:
    """
    加载 THCHS-30 测试集标注文件
    每个音频文件对应一个同名的 .wav.trn 文件

    Args:
        data_dir: 数据目录
        num_samples: 样本数量
        verbose: 是否打印详细信息
    """
    transcripts = []

    if not os.path.exists(data_dir):
        raise FileNotFoundError(f"数据目录不存在: {data_dir}")

    # 获取所有 .wav 文件
    wav_files = [f for f in os.listdir(data_dir) if f.endswith('.wav')]

    if len(wav_files) == 0:
        if verbose:
            print(f"⚠️ 警告: 在 {data_dir} 中没有找到 .wav 文件")
        return transcripts

    if verbose:
        print(f"找到 {len(wav_files)} 个音频文件")

    # 按文件名排序
    wav_files.sort()

    # 限制样本数量
    if num_samples > 0:
        wav_files = wav_files[:num_samples]
        if verbose:
            print(f"将测试前 {len(wav_files)} 个样本")

    success_count = 0
    for wav_file in wav_files:
        audio_id = wav_file[:-4]  # 去掉 .wav 后缀
        trn_file = os.path.join(data_dir, f"{audio_id}.wav.trn")

        if not os.path.exists(trn_file):
            if verbose and success_count < 10:
                print(f"⚠️ 标注文件不存在: {trn_file}")
            continue

        # 获取真实文本（自动解析路径引用，提取中文）
        real_text = get_real_text(trn_file, data_dir, verbose=verbose)

        # 验证是否为有效文本（非空且长度大于10）
        if real_text and len(real_text) > 10:
            transcripts.append((audio_id, real_text))
            success_count += 1
        else:
            if verbose and success_count < 10:
                print(f"⚠️ 无效标注内容: {trn_file} -> {real_text[:50] if real_text else '空'}")
            continue

    if verbose:
        print(f"✅ 成功加载了 {len(transcripts)} 条有效标注数据")

        # 显示第一个样本作为验证
        if transcripts:
            sample_id, sample_text = transcripts[0]
            print(f"📝 示例: {sample_id} -> {sample_text[:60]}...")

    return transcripts


def get_audio_path(audio_id: str, data_dir: str) -> str:
    """根据音频ID获取音频文件路径"""
    return os.path.join(data_dir, f"{audio_id}.wav")


# ==================== 评估指标计算 ====================

def calculate_metrics(reference: str, hypothesis: str) -> Dict[str, float]:
    """计算评估指标（CER 和 WER）"""
    # 归一化处理
    ref_norm = normalize_text(reference, remove_punct=True)
    hyp_norm = normalize_text(hypothesis, remove_punct=True)

    # 计算 CER（按字符）
    if ref_norm and hyp_norm:
        cer_score = cer(
            char_split(ref_norm),
            char_split(hyp_norm)
        )
    else:
        cer_score = 1.0 if ref_norm else 0.0

    # 计算 WER（按词）
    ref_words = ' '.join(list(ref_norm))
    hyp_words = ' '.join(list(hyp_norm))

    if ref_words and hyp_words:
        wer_score = wer(ref_words, hyp_words)
    else:
        wer_score = 1.0 if ref_words else 0.0

    return {
        "cer": cer_score * 100,
        "wer": wer_score * 100
    }


def is_sentence_correct(reference: str, hypothesis: str, threshold: float = 10.0) -> bool:
    """判断句子是否正确（基于 CER 阈值）"""
    metrics = calculate_metrics(reference, hypothesis)
    return metrics["cer"] < threshold


# ==================== 验证数据目录（仅测试用） ====================

def verify_data_directory(base_dir: str):
    """验证数据目录结构（仅测试时使用）"""
    print("=" * 60)
    print("验证数据目录结构")
    print("=" * 60)

    train_dir = os.path.join(base_dir, "train")
    data_dir = os.path.join(base_dir, "data")

    print(f"基础目录: {base_dir}")
    print(f"train 目录存在: {os.path.exists(train_dir)}")
    print(f"data 目录存在: {os.path.exists(data_dir)}")

    # 检查示例文件
    example_trn = os.path.join(train_dir, "A11_0.wav.trn")
    if os.path.exists(example_trn):
        with open(example_trn, 'r', encoding='utf-8') as f:
            content = f.read().strip()

        print(f"\n示例文件: A11_0.wav.trn")
        print(f"原始内容（第一行）: {content.split(chr(10))[0][:80]}...")

        # 如果是路径引用，显示真实路径
        if content.startswith('../'):
            real_path = os.path.normpath(os.path.join(train_dir, content))
            print(f"真实路径: {real_path}")
            print(f"真实文件存在: {os.path.exists(real_path)}")

            if os.path.exists(real_path):
                with open(real_path, 'r', encoding='utf-8') as f:
                    real_content = f.read().strip()
                # 显示提取后的中文
                extracted = extract_chinese_from_trn(real_content)
                print(f"提取的中文: {extracted[:80]}...")


# ==================== 主评估流程 ====================

def main():
    """主函数"""
    print("=" * 60)
    print("THCHS-30 语音识别性能测试（支持 CER/WER）")
    print("=" * 60)

    # 验证数据目录
    verify_data_directory(BASE_DATA_DIR)

    # 打印配置信息
    print(f"\n📂 数据集路径: {DATA_DIR}")
    print(f"💻 使用设备: {DEVICE}")
    print(f"📊 测试样本数: {NUM_TEST_SAMPLES if NUM_TEST_SAMPLES > 0 else '全部'}")

    # 1. 检查数据目录是否存在
    print(f"\n📂 检查数据目录...")
    if not os.path.exists(DATA_DIR):
        print(f"❌ 错误: 数据目录不存在 - {DATA_DIR}")
        print("请检查路径是否正确")
        return

    # 2. 加载标注文件（verbose=True 打印详细信息）
    print("\n📂 加载测试集标注...")
    try:
        transcripts = load_thchs30_transcripts(DATA_DIR, NUM_TEST_SAMPLES, verbose=True)
    except Exception as e:
        print(f"❌ 错误: {e}")
        return

    if not transcripts:
        print("❌ 未找到任何有效标注数据")
        print("请确认目录中包含 .wav 和对应的 .wav.trn 文件")
        return

    # 3. 加载模型
    print("\n🔧 加载模型...")
    analyzer = EmotionAnalyzer()

    # 4. 逐条测试
    print(f"\n🎤 开始测试 {len(transcripts)} 个样本...\n")

    results = []
    total_cer = 0.0
    total_wer = 0.0
    correct_sentences = 0
    failed_count = 0

    for idx, (audio_id, reference) in enumerate(tqdm(transcripts, desc="测试进度")):
        # 获取音频路径
        audio_path = get_audio_path(audio_id, DATA_DIR)

        # 检查音频文件是否存在
        if not os.path.exists(audio_path):
            print(f"\n⚠️ 跳过 {audio_id}: 音频文件不存在")
            failed_count += 1
            continue

        # 识别（使用 analyzer 的 transcribe 方法）
        hypothesis = analyzer.transcribe(audio_path)

        # 检查识别是否出错
        if hypothesis.startswith("[ERROR]"):
            print(f"\n⚠️ 跳过 {audio_id}: 识别出错 - {hypothesis}")
            failed_count += 1
            continue

        # 计算指标
        metrics = calculate_metrics(reference, hypothesis)
        cer_score = metrics["cer"]
        wer_score = metrics["wer"]

        # 判断句子是否正确
        is_correct = is_sentence_correct(reference, hypothesis)
        if is_correct:
            correct_sentences += 1

        # 累计
        total_cer += cer_score
        total_wer += wer_score

        # 保存结果
        results.append({
            "audio_id": audio_id,
            "reference": reference,
            "hypothesis": hypothesis,
            "cer": cer_score,
            "wer": wer_score,
            "is_correct": is_correct
        })

        # 打印前 5 个样本的详细信息
        if idx < 5:
            # 归一化后用于显示
            ref_norm = normalize_text(reference, remove_punct=True)
            hyp_norm = normalize_text(hypothesis, remove_punct=True)
            print(f"\n[{idx + 1}] {audio_id}.wav")
            print(f"  参考(原始): {reference[:80]}{'...' if len(reference) > 80 else ''}")
            print(f"  参考(归一): {ref_norm[:80]}{'...' if len(ref_norm) > 80 else ''}")
            print(f"  识别(原始): {hypothesis[:80]}{'...' if len(hypothesis) > 80 else ''}")
            print(f"  识别(归一): {hyp_norm[:80]}{'...' if len(hyp_norm) > 80 else ''}")
            print(f"  CER: {cer_score:.2f}% | WER: {wer_score:.2f}%")
            print(f"  状态: {'✅ 正确' if is_correct else '⚠️ 错误'}")

    # 如果没有有效结果，退出
    if len(results) == 0:
        print("\n❌ 没有成功处理任何样本")
        if failed_count > 0:
            print(f"失败样本数: {failed_count}")
        return

    # 5. 统计结果
    num_samples = len(results)
    avg_cer = total_cer / num_samples if num_samples > 0 else 0
    avg_wer = total_wer / num_samples if num_samples > 0 else 0
    ser = ((num_samples - correct_sentences) / num_samples * 100) if num_samples > 0 else 0

    # 6. 输出结果
    print("\n" + "=" * 60)
    print("测试结果统计")
    print("=" * 60)
    print(f"总样本数:      {num_samples}")
    print(f"正确句子数:    {correct_sentences}")
    print(f"错误句子数:    {num_samples - correct_sentences}")
    if failed_count > 0:
        print(f"失败/跳过:     {failed_count}")
    print("-" * 60)
    print(f"平均 CER:      {avg_cer:.2f}%")
    print(f"目标 CER:      ≤ 10%")
    print(f"平均 WER:      {avg_wer:.2f}%")
    print(f"目标 WER:      ≤ 10%")
    print(f"SER:           {ser:.2f}%")
    print(f"目标 SER:      ≤ 40%")
    print("-" * 60)

    # 判断是否达标
    cer_ok = avg_cer <= 10.0
    wer_ok = avg_wer <= 10.0
    ser_ok = ser <= 40.0

    if cer_ok and wer_ok and ser_ok:
        print("✅ 达标！所有指标均满足规范要求")
    else:
        print("❌ 不达标")
        if not cer_ok:
            print(f"   - CER 超标: {avg_cer:.2f}% > 10%")
        if not wer_ok:
            print(f"   - WER 超标: {avg_wer:.2f}% > 10%")
        if not ser_ok:
            print(f"   - SER 超标: {ser:.2f}% > 40%")

    # 7. 保存详细结果到 CSV
    with open(OUTPUT_CSV, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["音频ID", "参考文本", "识别文本", "CER(%)", "WER(%)", "是否正确"])

        for r in results:
            writer.writerow([
                r["audio_id"],
                r["reference"],
                r["hypothesis"],
                f"{r['cer']:.2f}",
                f"{r['wer']:.2f}",
                "是" if r["is_correct"] else "否"
            ])

    print(f"\n✅ 详细结果已保存到: {OUTPUT_CSV}")

    # 8. 保存汇总报告
    with open(OUTPUT_SUMMARY, 'w', encoding='utf-8') as f:
        f.write("=" * 60 + "\n")
        f.write("THCHS-30 语音识别性能测试报告\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"测试样本数: {num_samples}\n")
        f.write(f"正确句子数: {correct_sentences}\n")
        f.write(f"平均 CER: {avg_cer:.2f}%\n")
        f.write(f"平均 WER: {avg_wer:.2f}%\n")
        f.write(f"SER: {ser:.2f}%\n\n")
        if failed_count > 0:
            f.write(f"失败/跳过样本数: {failed_count}\n\n")
        f.write(f"达标情况:\n")
        f.write(f"  CER ≤ 10%: {'✅ 达标' if cer_ok else '❌ 不达标'}\n")
        f.write(f"  WER ≤ 10%: {'✅ 达标' if wer_ok else '❌ 不达标'}\n")
        f.write(f"  SER ≤ 40%: {'✅ 达标' if ser_ok else '❌ 不达标'}\n")

    print(f"✅ 汇总报告已保存到: {OUTPUT_SUMMARY}")
    print("\n" + "=" * 60)


# ==================== 单独测试情感分析 ====================

def test_emotion_analysis():
    """单独测试情感分析功能"""
    print("=" * 60)
    print("SenseVoice 情感分析测试")
    print("=" * 60)

    analyzer = EmotionAnalyzer()

    # 你可以在这里指定要测试的音频文件路径
    audio_path = input("\n请输入音频文件路径（或按Enter跳过）: ").strip()

    if audio_path and os.path.exists(audio_path):
        output = analyzer.analyze_sound(audio_path)
        print("\n=== 情感分析结果 ===")
        print(f"情感: {output['emotion']}")
        print(f"置信度: {output['confidence']}")
        print(f"原始输出: {output['raw_output']}")
        print(f"显示文本: {output['display_text']}")
    else:
        print("未提供有效的音频路径，跳过测试")


# ✅ 只在直接运行此脚本时执行测试代码
if __name__ == "__main__":
    # 运行语音识别性能测试
    main()

    # 如果需要单独测试情感分析，取消下面的注释
    # test_emotion_analysis()